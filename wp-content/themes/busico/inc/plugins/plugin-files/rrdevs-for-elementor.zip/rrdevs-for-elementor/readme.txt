=== RRaddons for Elementor ===
Contributors: rrdevs, rubelmah55
Donate link: https://profiles.wordpress.org/rrdevs/
Tags: Elementor, Elementor Addons, Elementor Free Custom Css, rrdevs
Requires at least: 5.0
Tested up to: 5.8.1
Requires PHP: 5.6
License: GPl V2
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html
Stable tag: 1.0.7


== Description ==

<p>

RRaddons for Elementor  For Elementor Helper Plugin

== Feature ==
* Custom CSS
* Nested section

== Available Widgets  ==
* Creative Buttons
* Advanced Slider
* Modal Popup
* Advanced Video Button
* Icon Box
* Breadcrumb
* Aniamte Text
* Contact Form 7
* PricingBox
* Excerpt
* Heading
* Advanced Tab


</p>


== Installation ==
Installation is fairly straight forward. Install it from the WordPress plugin repository.

== Changelog ==

= 1.0.0 =
* Initial Release
* Creative Buttons
* Advanced Slider

= 1.0.2 =
* Icon Box
* Breadcrumb
* Aniamte Text
* Contact Form 7


= 1.0.3 =
Heading
Excerpt

= 1.0.4 =
* PricingBox
* Advanced Tab
* Advanced Video Button
* Modal Popup

= 1.0.5 =
* ProgressBar
* Accordion


