<?php
/**
 * busico Image Carousel.
 *
 *
 * @since 1.0.0
 */
use  Elementor\Widget_Base;
use  Elementor\Controls_Manager;
use  Elementor\utils;
use  Elementor\Group_Control_Typography;
use  Elementor\Group_Control_Box_Shadow;
use  Elementor\Group_Control_Background;
use  Elementor\Group_Control_Border;
use  Elementor\Embed;
use  Elementor\Icons_Manager;
use  Elementor\Repeater;
if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Busico_Testimonial_Slider_default extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'busico-testimonial-2';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Busico Testimonial Two', 'busico-hp');
    }

    public function get_keywords(){
        return ['iamge ', 'carousel','hero one', 'slider' ];
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-image-rollover';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['busico-addons'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */


    protected function register_controls()
    {
        /**
         * ====================================Content tab========================================
         */
        $this->start_controls_section(
            'h2_content_section',
            [
                'label' => __('Content', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'user_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
            'blockqoute_icon',
            [
                'label' => __( 'Blockqoute Icon', 'busico-hp' ),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::ICONS,

                'default' => [
                    'value' => 'fas fa-arrow-right',
                    'library' => 'fa-solid',
                ],
            ]
           );

        $repeater->add_control(
            'h_discription',
            [
                'label'       => __( 'Short Discription', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __('Contrary to popular belief Lorem Ipsum is not simply random text it has roots in a piece of classical Latin literature from 45 BC, making it over, Contrary to popular belief.', 'busico-hp'),
            ]
        );

		$repeater->add_control(
            'h_user_name',
            [
                'label'       => __( 'User Name', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __(' Sr. Stiphen Robert', 'busico-hp'),
            ]
        );
        $repeater->add_control(
            'h_user_des',
            [
                'label'       => __( 'User Description', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __('Software Engineer', 'busico-hp'),
            ]
        );

        $repeater->add_control(
			'review_rating',
			[
				'label' => esc_html__( 'rating review', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '5',
				'options' => [
					'1'  => esc_html__( '1', 'busico-hp' ),
					'2' => esc_html__( '2', 'busico-hp' ),
					'3' => esc_html__( '3', 'busico-hp' ),
					'4' => esc_html__( '4', 'busico-hp' ),
					'5' => esc_html__( '5', 'busico-hp' ),
				],
			]
		);

		$repeater->add_control(
            'rating_icon',
            [
                'label' => __( 'Rating Icon', 'busico-hp' ),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::ICONS,

                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'fa-solid',
                ],
            ]
           );



        // End Repeater Control field
        $this->add_control(
            'h2_contents',
            [
                'label' => __( 'Repeater List', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(h_user_name.slice(0,1).toUpperCase() + h_user_name.slice(1)) #>',
            ]
        );

        $this->end_controls_section();
		
		
        // ===============================Content Style tab =====================================

        $this->start_controls_section('content_style',
            [
            'label' => __('Contents', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

           $this->add_responsive_control(
            'slider_content_align',
            [
                'label' => __( 'Alignment', 'busico-hp' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'busico-hp' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'busico-hp' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'busico-hp' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .busico-single-testimonial-item2' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        // =============================== Image Style tab =====================================

        $this->add_control(
            'user_thumb',
            [
                'label' => __( 'Image', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );


          $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'      => 'image_border',
                'selector'  => '{{WRAPPER}} .busico-testimonial-thumb img',
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'image_box_shadow',
                'exclude'  => [
                    'box_shadow_position',
                ],
                'selector' => '{{WRAPPER}} .busico-testimonial-thumb img',
            ]
        );



        $this->add_responsive_control(
            'width',
            [
                'label'          => __('Width', 'busico-hp'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .busico-testimonial-thumb img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'space',
            [
                'label'          => __('Max Width', 'busico-hp'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['px', '%', 'vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .busico-testimonial-thumb img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'height',
            [
                'label'          => __('Height', 'busico-hp'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['px', 'vh'],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .busico-testimonial-thumb img' => 'height: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );

        $this->add_responsive_control(
            'user_thumb_border_radius',
            [
                'label'      => __('Border Radius', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-testimonial-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-testimonial-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'user_thumb_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-testimonial-thumb img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-testimonial-thumb img' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );


         // =============================== Blockquote Style tab =====================================
        $this->add_control(
            'blockquote_icon',
            [
                'label' => __( 'Blockquote Icon', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'blockquote_icon_color',
            [
                'label' => __('Blockquote Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .busico-single-testimonial-item2 i' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                    '{{WRAPPER}} .busico-single-testimonial-item2 svg path' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'blockquote_icon_fill_color',
            [
                'label' => __('Blockquote fill Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .busico-single-testimonial-item2 svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'blockquote_icon_size',
            [
                'label' => __('Icon Size', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .busico-single-testimonial-item2  i' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}}  .busico-single-testimonial-item2 svg' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'blockquote_icon_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-single-testimonial-item2 i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .busico-single-testimonial-item2 svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
            ]
        );

        //=================================== End Blockquote Icon ==================================


        //=================================== Discription ==================================
        $this->add_control(
			'h2_dis_title',
			[
				'label' => __( 'Discription', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
        $this->add_control(
            'h2_dis_title_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .busico-single-testimonial-item2 p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'dis_title_typo',
                'label'    => __('Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}} .busico-single-testimonial-item2 p',
            ]
        );
        $this->add_responsive_control(
            'p_dis_title_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-single-testimonial-item2 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-single-testimonial-item2 p' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        //=================================== Testimonial User Name ==================================
        $this->add_control(
            'user_name',
            [
                'label' => __( 'User Name', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );
        $this->add_control(
            'user_name_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-user-author h4' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'user_name_typo',
                'label'    => __('Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}} .testimonial-user-author h4',
            ]
        );
        $this->add_responsive_control(
            'user_name_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-user-author h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .testimonial-user-author h4' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

         //=================================== Testimonial User Des ==================================
        $this->add_control(
            'user_des',
            [
                'label' => __( 'User Description', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );
        $this->add_control(
            'user_des_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-user-author p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'user_des_typo',
                'label'    => __('Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}} .testimonial-user-author p',
            ]
        );
        $this->add_responsive_control(
            'user_des_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-user-author p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .testimonial-user-author p' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        //=================================== Testimonial Ratting ==================================
        $this->add_control(
            'user_rating',
            [
                'label' => __( 'User Rating', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );
        $this->add_control(
            'user_rating_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .busico--tn-icon i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .busico--tn-icon svg path' => 'stroke: {{VALUE}};',

                ],
            ]
        );

        $this->add_control(
            'rating_icon_fill_color',
            [
                'label' => __('Fill Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .busico--tn-icon svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'user_rating_size',
            [
                'label' => __('Icon Size', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .busico--tn-icon i' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}}  .busico--tn-icon svg' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'user_rating_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico--tn-icon i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico--tn-icon i' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        //=================================== Testimonial Ratting ==================================
        $this->add_control(
            'testimonial_box',
            [
                'label' => __( 'Box', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_responsive_control(
            'testimonial_box_padding',
            [
                'label'      => __('Padding', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-single-testimonial-item2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-single-testimonial-item2' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();

        

        /*
        * ============================= Dots Style ==============================================
        */
        $this->start_controls_section(
            'dots_navigation',
            [
                'label' => __('Navigation - Dots', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs('_tabs_dots');

        $this->start_controls_tab(
            '_tab_dots_normal',
            [
                'label' => __('Normal', 'busico-hp'),
            ]
        );

        $this->add_control(
            'dots_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot span' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_align',
            [
                'label' => __( 'Alignment', 'busico-hp' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'busico-hp' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'busico-hp' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'busico-hp' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'dots_box_width',
            [
                'label' => __('Width', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot span' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_box_height',
            [
                'label' => __('Height', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot span' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_margin',
            [
                'label'          => __('Gap Right', 'busico-hp'),
                'type'           => Controls_Manager::SLIDER,
                'default'        => [
                    'unit' => 'px',
                ],
                'range'          => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot span ' => 'margin-right: {{SIZE}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot span ' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'dots_min_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                    'body.rtl {{WRAPPER}} .busico-testimonial-2 .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}} !important;',
                ],
            ]
        );
        $this->add_responsive_control(
            'dots_border_radius',
            [
                'label'      => __('Border Radius', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot span' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

            // ======================= Dots Active Style =======================================

        $this->start_controls_tab(
            '_tab_dots_active',
            [
                'label' => __('Active', 'busico-hp'),
            ]
        );
        $this->add_control(
            'dots_color_active',
            [
                'label' => __('Active Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot.active span' => 'background-color: {{VALUE}}  !important;',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrow_dots_box_active_width',
            [
                'label' => __('Width', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot.active span' => 'width: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrow_dots_box_active_height',
            [
                'label' => __('Height', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-dots .owl-dot.active span' => 'height: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
                /*
        *
           ================================== Arrow style =======================
        */
        $this->start_controls_section(
            'arrows_navigation',
            [
                'label' => __('Navigation - Arrow', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('_tabs_arrow');

        $this->start_controls_tab(
            '_tab_arrow_normal',
            [
                'label' => __('Normal', 'busico-hp'),
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 button i' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                    '{{WRAPPER}} .busico-testimonial-2 button i svg path' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg_color',
            [
                'label' => __('Background Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 button i' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrow_align',
            [
                'label' => __( 'Alignment', 'busico-hp' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'busico-hp' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'busico-hp' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'busico-hp' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 .owl-nav' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrow_shadow',
                'label' => __('Shadow', 'fd-addons'),
                'selector' => '{{WRAPPER}} .busico-testimonial-2 button i ',
            ]
        );

        $this->add_responsive_control(
            'arrow_icon_size',
            [
                'label' => __('Icon Size', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .busico-testimonial-2 button i' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}}  .busico-testimonial-2 button svg' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrow_size_box',
            [
                'label' => __('Size', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 button i' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}',
                ],
            ]

        );

        $this->add_responsive_control(
            'arrow_size_line_height',
            [
                'label' => __('Line Height', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 button i' => 'line-height: {{SIZE}}{{UNIT}} !important;',
                ],
            ]

        );

        $this->add_responsive_control(
            'arrows_border_radius',
            [
                'label'      => __('Border Radius', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-testimonial-2 button i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-testimonial-2 button i ' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
         $this->add_responsive_control(
            'arrows_border_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-testimonial-2 button i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-testimonial-2 button i' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

            //==============================Arrow Hover Style =============================

        $this->start_controls_tab(
            '_tab_arrow_hover',
            [
                'label' => __('Hover', 'busico-hp'),
            ]
        );

        $this->add_control(
            'arrow_hover_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 button i:hover ' => 'color: {{VALUE}} !important;',
                    '{{WRAPPER}} .busico-testimonial-2 button i:hover svg path ' => 'stroke: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg_hover_color',
            [
                'label' => __('Background Color Hover', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .busico-testimonial-2 button i:hover ' => 'background-color: {{VALUE}}  !important;',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        // Slider Option
        $this->start_controls_section('slider_settings',
            [
            'label' => __('Slider Settings', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'arrows',
            [
                'label' => __( 'Show arrows?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'dots',
            [
                'label' => __( 'Show Dots?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'mousedrag',
            [
                'label' => __( 'MouseDrag?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __( 'Auto Play?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'loop',
            [
                'label' => __( 'Infinite Loop', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'true',
            ]
        );
        $this->add_control(
            'autoplaytimeout',
            [
                'label' => __( 'Autoplay Timeout', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'label_block' => true,
                'default' => '5000',
                'options' => [
                    '1000'  => __( '1 Second', 'busico-hp' ),
                    '2000'  => __( '2 Second', 'busico-hp' ),
                    '3000'  => __( '3 Second', 'busico-hp' ),
                    '4000'  => __( '4 Second', 'busico-hp' ),
                    '5000'  => __( '5 Second', 'busico-hp' ),
                    '6000'  => __( '6 Second', 'busico-hp' ),
                    '7000'  => __( '7 Second', 'busico-hp' ),
                    '8000'  => __( '8 Second', 'busico-hp' ),
                    '9000'  => __( '9 Second', 'busico-hp' ),
                    '10000' => __( '10 Second', 'busico-hp' ),
                    '11000' => __( '11 Second', 'busico-hp' ),
                    '12000' => __( '12 Second', 'busico-hp' ),
                    '13000' => __( '13 Second', 'busico-hp' ),
                    '14000' => __( '14 Second', 'busico-hp' ),
                    '15000' => __( '15 Second', 'busico-hp' ),
                ],
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();



        // Slider Option
    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $contents =  $settings['h2_contents'];

         // Slider Option
         $slider_extraSetting = array(
	        'loop' => (!empty($settings['loop']) && 'yes' === $settings['loop']) ? true : false,
	        'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
        	'nav' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,
        	'dots' => (!empty($settings['dots']) && 'yes' === $settings['dots']) ? true : false,
        	'mousedrag' => (!empty($settings['mousedrag']) && 'yes' === $settings['mousedrag']) ? true : false,
        	'autoplaytimeout' => !empty($settings['autoplaytimeout']) ? $settings['autoplaytimeout'] : '5000',
        );

        $jasondecode = wp_json_encode($slider_extraSetting);


        $this->add_render_attribute('slider_active', 'class', array('busico-testimonial-2','owl-carousel'));
        $this->add_render_attribute('slider_active', 'data-settings', $jasondecode);



       ?>

		<div <?php echo $this->get_render_attribute_string('slider_active'); ?>>
        <?php foreach($contents as $content):?>
          
			<div class="busico-single-testimonial-item2">
				<div class="busico-testimonial-thumb">
					<?php if($content['user_thumb'] ): ?>
						<img src="<?php echo esc_url($content['user_thumb']['url']); ?>" alt="">
					<?php endif; ?>
					<?php \Elementor\Icons_Manager::render_icon( $content['blockqoute_icon'] ); ?>
				</div>

				<div class="testimonial-user-author">
                    <?php if($content['h_user_name'] ): ?>
                        <h4><?php echo esc_html($content['h_user_name']);  ?></h4>
                    <?php endif; ?>
                    <?php if($content['h_user_des'] ): ?>
                        <p><?php echo esc_html($content['h_user_des']);  ?></p>
                    <?php endif; ?>
                </div>

				<?php if($content['h_discription'] ): ?>
               		<p><?php echo esc_html($content['h_discription']); ?></p>
				<?php endif; ?>

                
				<?php if($content['review_rating'] ):    
				            $ratting = $content['review_rating'];
				        ?>
			        <div class="busico--tn-icon">
			            <?php for($i=0;$i<$ratting;$i++): ?>
			                <?php \Elementor\Icons_Manager::render_icon($content['rating_icon'], ['aria-hidden' => 'true']) ?>
			            <?php endfor; ?>
			        </div>
				<?php endif; ?>
                    
				</div>

            <?php endforeach; ?>

		</div>
    <?php
    }
}
$widgets_manager->register_widget_type(new \Busico_Testimonial_Slider_default());