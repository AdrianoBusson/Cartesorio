<?php
/**
 * busico Image Carousel.
 *
 *
 * @since 1.0.0
 */
namespace rr_Addons\Widgets;

use  Elementor\Widget_Base;
use  Elementor\Controls_Manager;
use  Elementor\utils;
use  Elementor\Group_Control_Typography;
use  Elementor\Group_Control_Box_Shadow;
use  Elementor\Group_Control_Background;
use  Elementor\Group_Control_Border;
use  Elementor\Embed;
use  Elementor\Icons_Manager;
use  Elementor\Repeater;
if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Busico_Hero_One extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'busico-hero-one';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Hero Section One', 'busico-hp');
    }

    public function get_keywords(){
        return ['iamge ', 'carousel','hero one', 'slider' ];
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-image-rollover';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['busico-addons'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */


    protected function register_controls()
    {
        /**
         * Content tab
         */
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Slider Content', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'active_slider',
            [
                'label' => __( 'Active Slider', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_social_links',
            [
                'label' => __( 'Show Social Links', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'background_image',
            [
                'label'       => __( 'Background Image', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __('we build Your Dream', 'busico-hp'),
            ]
        );

        $repeater->add_control(
            'discription',
            [
                'label'       => __( 'Short Discription', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __('Busico is a construction and architecture environmentally most
                responsible for any kinds of themes.', 'busico-hp'),
            ]
        );

        $repeater->add_control(
			'',
			[
				'label' => __( 'Button One', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
        $repeater->add_control(
            'btn_one_text',
            [
                'label'       => __( 'Button Text', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __('contact us', 'busico-hp'),
            ]
        );

        $repeater->add_control(
            'btn_one_url',
            [
                'label'       => __( 'Button Url', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::URL,
                'label_block' => true,
            ]
        );


        $repeater->add_control(
			'h_btn_two',
			[
				'label' => __( 'Button Two', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);

        $repeater->add_control(
            'btn_two_text',
            [
                'label'       => __( 'Button Text', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __('Explore <br> More about Us', 'busico-hp'),
            ]
        );
        $repeater->add_control(
            'btn_two_url',
            [
                'label'       => __( 'Button Url', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::URL,
                'label_block' => true,
            ]
        );
       

        // End Repeater Control field
        $this->add_control(
            'contents',
            [
                'label' => __( 'Repeater List', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(title.slice(0,1).toUpperCase() + title.slice(1)) #>',
            ]
        );
        $this->end_controls_section();

        /**
         * Icons
         */
        $this->start_controls_section(
            'content_section_icon',
            [
                'label' => __('Icon list', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'show_social_links' => 'yes',
                ], 
            ]
        );
        $this->add_control(
            'flow_us',
            [
                'label'       => __( 'Text ', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __('Follow Us', 'busico-hp'),
            ]
        );

        $repeater_icon = new \Elementor\Repeater();

        $repeater_icon->add_control(
            's_link',
            [
                'label'       => __( 'Icon', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::ICONS,
            ]
        );
        $repeater_icon->add_control(
            'social_url',
            [
                'label'       => __( 'Url', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        // End Repeater Control field
          $this->add_control(
            'social_links_area',
            [
                'label' => __( 'Social Links', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater_icon->get_controls(),
            ]
        );
        $this->end_controls_section();

        // Container
        $this->start_controls_section('container_style',
            [
            'label' => __('Container', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'hero_one_background',
				'label' => esc_html__( 'Background Overly', 'busico-hp' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .hero-1 .single-slide:after',
			]
		);
        $this->end_controls_section();

        // Heading
        $this->start_controls_section('heading_style',
            [
            'label' => __('Heading', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .hero-title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typo',
                'label'    => __('Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}}   .hero-title',
            ]
        );
        $this->add_responsive_control(
            'title_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}}  .hero-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}}  .hero-title' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

         // Content
         $this->start_controls_section('discription_style',
         [
            'label' => __('Discription', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'dis_title_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-discription' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'dis_title_typo',
                'label'    => __('Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}} .hero-discription',
            ]
        );
        $this->add_responsive_control(
            'dis_title_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-discription' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-discription' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'dis_padding',
            [
                'label'      => __('Padding', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-discription' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-discription' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'content_box_style',
            [
                'label' => __( 'Content Box Style', 'busico-hp' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'content_padding',
            [
                'label'      => __('Padding', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px','%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-contents' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-contents' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();


        // Button Style One
        $this->start_controls_section(
            'button_style',
            [
                'label' => __( 'Button One', 'busico-hp' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'button_style_tabs'
        );

        $this->start_controls_tab(
            'button_style_normal_tab',
            [
                'label' => __( 'Normal', 'busico-hp' ),
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'btn_typography',
                'label'    => __( 'Typography', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-1 .hero-contents .theme-btn',
            ]
        );
        $this->add_control(
            'boxed_btn_color',
            [
                'label'     => __( 'Button Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .hero-contents .theme-btn' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'boxed_btn_background',
            [
                'label'     => __( 'Background Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .hero-contents .theme-btn' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'button_border',
                'label'    => __( 'Border', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-1 .hero-contents .theme-btn',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_shadow',
                'label'    => __( 'Button Shadow', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-1 .hero-contents .theme-btn',
            ]
        );
        $this->add_responsive_control(
            'button_radius',
            [
                'label'      => __( 'Border Radius', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-1 .hero-contents .theme-btn'          => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-1 .hero-contents .theme-btn' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}}
                    ;',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_margin',
            [
                'label'      => __( 'Button Margin', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-1 .hero-contents .theme-btn'          => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-1 .hero-contents .theme-btn' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_padding',
            [
                'label'      => __( 'Button Padding', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-1 .hero-contents .theme-btn'          => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-1 .hero-contents .theme-btn' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'button_icon_margin',
            [
                'label'      => __( 'Button Icon Margin', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-contents .hero-1 .hero-contents .theme-btn i'          => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-contents .hero-1 .hero-contents .theme-btn i' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_style_hover_tab',
            [
                'label' => __( 'Hover', 'busico-hp' ),
            ]
        );
        $this->add_control(
            'btn_hover_color',
            [
                'label'     => __( 'Button Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .hero-contents .theme-btn:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'btn_hover_bg_color',
            [
                'label'     => __( 'Background Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .hero-contents .theme-btn:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'button_hover_border',
                'label'    => __( 'Border', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-1 .hero-contents .theme-btn:hover',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_hover_shadow',
                'label'    => __( 'Button Shadow', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-1 .hero-contents .theme-btn:hover',
            ]
        );
        $this->add_responsive_control(
            'button_hover_radius',
            [
                'label'      => __( 'Border Radius', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-1 .hero-contents .theme-btn:hover'          => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-1 .hero-contents .theme-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}}
                    ;',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        // Button Style Two
        $this->start_controls_section(
            'button_style_two',
            [
                'label' => __( 'Button Two', 'busico-hp' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'button_style_tabs_two'
        );

        $this->start_controls_tab(
            'button_style_normal_tab_two',
            [
                'label' => __( 'Normal', 'busico-hp' ),
            ]
        );

        $this->add_control(
			'button_two_text',
			[
				'label' => __( 'Text', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'btn_typography_two',
                'label'    => __( 'Typography', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-1 .hero-contents .plus-text-btn .link-text p',
            ]
        );

        $this->add_control(
            'boxed_btn_color_two',
            [
                'label'     => __( 'Button Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .hero-contents .plus-text-btn .link-text p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
			'button_two_icon',
			[
				'label' => __( 'Icon', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'btn_typography_icon_two',
                'label'    => __( 'Typography', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-contents .plus-text-btn .icon',
            ]
        );

        $this->add_control(
            'boxed_btn_color_icon_two',
            [
                'label'     => __( 'Icon Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .hero-contents .plus-text-btn .icon' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_margin_icon_two',
            [
                'label'      => __( 'Icon Margin', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-1 .hero-contents .plus-text-btn .icon'          => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-1 .hero-contents .plus-text-btn .icon' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_style_hover_tab_two',
            [
                'label' => __( 'Hover Icon', 'busico-hp' ),
            ]
        );
        $this->add_control(
            'btn_hover_color_two',
            [
                'label'     => __( 'Button Text Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .hero-contents .plus-text-btn:hover .icon' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'btn_hover_bg_color_two',
            [
                'label'     => __( 'Button Icon background Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .hero-contents .plus-text-btn:hover .icon' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section(
            'fllow_us_style',
            [
                'label' => __( 'Social links', 'busico-hp' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'socail_bg_color',
            [
                'label'     => __('Wraper Background', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .hero-social-elements' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'socail_wraper_shadow',
                'label' => __('Shadow', 'busico-hp'),
                'selector' => '{{WRAPPER}} .hero-social-elements ',
            ]
        );
        $this->add_responsive_control(
            'socail_wraper_width',
            [
                'label' => __('Width', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .hero-social-elements' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'socail_text_typo',
                'label'    => __('Text Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}}   ..hero-social-elements .flp-text',
            ]
        );

        $this->add_control(
            'socail_text_color',
            [
                'label'     => __('Text Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  ..hero-social-elements .flp-text' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->start_controls_tabs(
            'socail_normal'
        );

        $this->start_controls_tab(
            'socail_normal_style',
            [
                'label' => __( 'Normal', 'busico-hp' ),
            ]
        );

        $this->add_control(
            'socail_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .hero-social-elements .social-link a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'socail_color_bg',
            [
                'label'     => __('Background Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .hero-social-elements .social-link a' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'text_',
                'label'    => __('Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}}   .hero-social-elements .social-link a',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'socailborder',
                'label'    => __( 'Border', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-social-elements .social-link a',
            ]
        );
        $this->add_responsive_control(
            'socail_padding',
            [
                'label'      => __('padding', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}}  .hero-social-elements .social-link a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}}  .hero-social-elements .social-link a' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'socail_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}}  .hero-social-elements .social-link a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}}  .hero-social-elements .social-link a' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'socail_border_radius',
            [
                'label'      => __('Border Radius', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}}  .hero-social-elements .social-link a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}}  .hero-social-elements .social-link a' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
       
        $this->end_controls_tab();


        $this->start_controls_tab(
            'socail_hover_style',
            [
                'label' => __( 'Hover', 'busico-hp' ),
            ]
        );
        $this->add_control(
            'socail_color_hover',
            [
                'label'     => __('Hover Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .hero-social-elements .social-link a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'socail_color_bg_hover',
            [
                'label'     => __('Background Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .hero-social-elements .social-link a:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        // Slider Option
        $this->start_controls_section('slider_settings',
            [
                'label' => __('Slider Settings', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'active_slider' => 'yes',
                ], 

            ]
        );
        

        $this->add_control(
            'arrows',
            [
                'label' => __( 'Show arrows?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'dots',
            [
                'label' => __( 'Show Dots?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'mousedrag',
            [
                'label' => __( 'MouseDrag?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __( 'Auto Play?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'loop',
            [
                'label' => __( 'Infinite Loop', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'true',
            ]
        );
        $this->add_control(
            'autoplaytimeout',
            [
                'label' => __( 'Autoplay Timeout', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'label_block' => true,
                'default' => '5000',
                'options' => [
                    '1000'  => __( '1 Second', 'busico-hp' ),
                    '2000'  => __( '2 Second', 'busico-hp' ),
                    '3000'  => __( '3 Second', 'busico-hp' ),
                    '4000'  => __( '4 Second', 'busico-hp' ),
                    '5000'  => __( '5 Second', 'busico-hp' ),
                    '6000'  => __( '6 Second', 'busico-hp' ),
                    '7000'  => __( '7 Second', 'busico-hp' ),
                    '8000'  => __( '8 Second', 'busico-hp' ),
                    '9000'  => __( '9 Second', 'busico-hp' ),
                    '10000' => __( '10 Second', 'busico-hp' ),
                    '11000' => __( '11 Second', 'busico-hp' ),
                    '12000' => __( '12 Second', 'busico-hp' ),
                    '13000' => __( '13 Second', 'busico-hp' ),
                    '14000' => __( '14 Second', 'busico-hp' ),
                    '15000' => __( '15 Second', 'busico-hp' ),
                ],
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();

       /*
        * 
           ================================== Arrow style =======================
        */
        $this->start_controls_section(
            'arrows_navigation',
            [
                'label' => __('Navigation - Arrow', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('_tabs_arrow');

        $this->start_controls_tab(
            '_tab_arrow_normal',
            [
                'label' => __('Normal', 'busico-hp'),
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .owl-nav div' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg_color',
            [
                'label' => __('Background Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .owl-nav div' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );


        $this->add_responsive_control(
            'arrow_icon_size',
            [
                'label' => __('Icon Size', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .hero-1 .owl-nav div i' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->end_controls_tab();

            //==============================Arrow Hover Style =============================

        $this->start_controls_tab(
            '_tab_arrow_hover',
            [
                'label' => __('Hover', 'busico-hp'),
            ]
        );

        $this->add_control(
            'arrow_hover_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .owl-nav div:hover ' => 'color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg_hover_color',
            [
                'label' => __('Background Color Hover', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-1 .owl-nav div:hover ' => 'background-color: {{VALUE}}  !important;',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $contents =  $settings['contents'];
        $social_links_area =  $settings['social_links_area'];

        // Slider Option
        $slider_extraSetting = array(
	        'loop' => (!empty($settings['loop']) && 'yes' === $settings['loop']) ? true : false,
	        'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
        	'nav' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,
        	'dots' => (!empty($settings['dots']) && 'yes' === $settings['dots']) ? true : false,
        	'mousedrag' => (!empty($settings['mousedrag']) && 'yes' === $settings['mousedrag']) ? true : false,
        	'autoplaytimeout' => !empty($settings['autoplaytimeout']) ? $settings['autoplaytimeout'] : '5000',
        );
        $jasondecode = wp_json_encode($slider_extraSetting);

        $this->add_render_attribute('slider_active', 'class', array('hero-slider-active','owl-carousel'));
        $this->add_render_attribute('slider_active', 'data-settings', $jasondecode);

        ?>

        <!-- social links -->
        <?php if($settings['show_social_links']): ?>
            <div class="hero-social-elements d-xxl-block">

                <div class="flp-text">
                    <p><?php echo esc_html($settings['flow_us']); ?></p>
                </div>

                <div class="long-arrow"></div>
                <div class="social-link">
                        <?php foreach($social_links_area as $links):
                            $l_target =   $links['social_url']['is_external'] ? ' target="_blank" ' : '';
                            $l_nofollow = $links['social_url']['nofollow'] ? ' rel="nofollow" ' : '';
                        ?>
                        <a <?php printf('href="%s" %s %s', $links['social_url']['url'], $l_target, $l_nofollow); ?>>
                            <?php \Elementor\Icons_Manager::render_icon( $links['s_link'] ); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        <!-- social links end-->

        
        <section class="hero-wrapper hero-1">
            <div <?php echo $this->get_render_attribute_string('slider_active'); ?>>
                <?php foreach($contents as $content):  ?>


                    <?php
                    $target =   $content['btn_one_url']['is_external'] ? ' target="_blank" ' : '';
                    $nofollow = $content['btn_one_url']['nofollow'] ? ' rel="nofollow" ' : '';

                    $target_two =   $content['btn_two_url']['is_external'] ? ' target="_blank" ' : '';
                    $nofollow_two = $content['btn_two_url']['nofollow'] ? ' rel="nofollow" ' : '';
                        
                    ?>

                    
                    <div class="single-slide bg-cover" style="background-image: url(<?php echo esc_url($content['background_image']['url']);?>)">
                        <div class="container">
                            <div class="row">
                                <div class="col-12 ps-md-5 pe-md-5 col-xxl-7 col-lg-8 col-md-10 col-sm-12">
                                    <div class="hero-contents pe-lg-3">

                                        <?php if($content['title']): ?>
                                            <h1 class="fs-lg hero-title wow fadeInLeft animated" data-wow-duration="1.3s">
                                                <?php echo esc_html($content['title']); ?>
                                            </h1>
                                        <?php endif; ?>

                                        <?php if($content['discription']): ?>
                                            <p class="pe-lg-5 hero-discription wow fadeInLeft animated" data-wow-duration="1.3s"
                                                data-wow-delay=".4s">
                                                <?php echo esc_html($content['discription']); ?>
                                            </p>
                                        <?php endif; ?>

                                        <?php if($content['btn_one_text']): ?>
                                            <a <?php printf('href="%s" %s %s', $content['btn_one_url']['url'], $target, $nofollow); ?> class="theme-btn me-sm-4 wow fadeInLeft" data-wow-duration="1.2s"
                                                data-wow-delay=".8s">
                                                <?php echo esc_html($content['btn_one_text']); ?>
                                            </a>
                                        <?php endif; ?>

                                        <?php if($content['btn_two_text']): ?>
                                            <a <?php printf('href="%s" %s %s', $content['btn_two_url']['url'], $target, $nofollow); ?> class="plus-text-btn wow fadeInLeft" data-wow-duration="1.2s"
                                                data-wow-delay=".6s">
                                                <div class="icon">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <div class="link-text">
                                                    <?php echo busico_get_meta($content['btn_two_text']); ?>
                                                </div>
                                            </a>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="slider-nav"></div>
        </section>
        
        <?php
    }
}
$widgets_manager->register_widget_type(new \rr_Addons\Widgets\Busico_Hero_One());


