<?php
if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly
/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Busico_Portfolio_Gallery extends \Elementor\Widget_Base
{
    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'busico-portfolio-gallery';
    }

    public function get_script_depends()
    {
        return ['isotope', 'busico-addon'];
    }
    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Busico Portfolio Gallery', 'busico-hp');
    }
    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }
    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['busico-addons'];
    }
    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls()
    {
        $this->start_controls_section(
            'section_gallery',
            [
                'label' => __('Gallery', 'busico-hp'),
            ]
        );
        

        $this->add_control(
            'layout_type',
            [
                'label' => __('Layout type', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    'masonry' => 'Masonry',
                    'normal' => 'Normal',
                    'slider' => 'Slider'
                ),
                'default' => 'masonry',
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
        );
        
        $repeater->add_control(
			'image_size',
			[
				'label' => __( 'Image Dimension', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::IMAGE_DIMENSIONS,
				'description' => __( 'Crop the original image size to any custom size. Set custom width or height to keep the original size ratio.', 'busico-hp' ),
				'default' => [
					'width' => '',
					'height' => '',
				],
			]
        );
        $repeater->add_responsive_control(
            'image_grid',
            [
                'label' => __('Image grid', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    '' => 'Default',
                    '12' => '1 Column',
                    '6' => '2 Column',
                    '4' => '3 Column',
                    '3' => '4 Column',
                ),
                'default'            => '',
            ]
        );
        
        $repeater->add_control(
			'image_title',
			[
				'label' => __( 'Title', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your title here', 'plugin-domain' ),
			]
		);

		$this->add_control(
			'gallery_list',
			[
				'label' => __( 'Repeater List', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ image_title }}}',
			]
        );
        
       
        
        
        $this->end_controls_section();
        $this->start_controls_section(
            'section_width_nd_height',
            [
                'label' => __('Width & Height', 'busico-hp'),
            ]
        );


        $this->add_responsive_control(
            'post_grid',
            [
                'label' => __('Post grid', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => array(
                    '12' => '1 Column',
                    '6' => '2 Column',
                    '4' => '3 Column',
                    '3' => '4 Column',
                ),
                'default'            => 3,
                'condition' => [
                    'layout_type!' => 'slider'
                ]
            ]
        );

        $this->add_responsive_control(
            'column_verti_gap',
            [
                'label' => __('Column Vertical Gap', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'devices' => ['desktop', 'tablet', 'mobile'],
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'desktop_default' => [
                    'size' => 15,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}}  .busico-portfolio-item-wrap' => 'padding: 0 {{SIZE}}{{UNIT}} 0;',
                ]
            ]
        );

        $this->add_responsive_control(
            'column_hori_gap',
            [
                'label' => __('Column Horizontal Gap', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'devices' => ['desktop', 'tablet', 'mobile'],
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'desktop_default' => [
                    'size' => 30,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}}  .busico-portfolio-item-wrap' => 'padding-bottom: {{SIZE}}{{UNIT}} ;',
                ],
                'condition' => [
                    'layout_type!' => 'slider'
                ]
            ]
        );
        $this->add_control(
            'use_custom_height',
            [
                'label' => __('Use custom height?', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'busico-hp'),
                'label_off' => __('No', 'busico-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $this->add_responsive_control(
            'normal_image_height',
            [
                'label' => __('Normal Image Height', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'devices' => ['desktop', 'tablet', 'mobile'],
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .busico-portfolio-item img' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'use_custom_height' => 'yes'
                ],
            ]
        );

        $this->end_controls_section();
              
    //Slider Setting
    $this->start_controls_section('slider_settings',
    [
            'label' => __('Slider Settings', 'busico-hp'),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            'condition' => [
                'layout_type' => 'slider'
            ]
            ]
        );

        $this->add_responsive_control(
            'per_coulmn',
            [
                'label' => __( 'Slider Items', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default'            => 3,
                'tablet_default'     => 2,
                'mobile_default'     => 1,
                'options'            => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                ],
                'frontend_available' => true,
            ]
        );
        $this->add_control(
            'arrows',
            [
                'label' => __( 'Show arrows?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'dots',
            [
                'label' => __( 'Show Dots?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'mousedrag',
            [
                'label' => __( 'Show MouseDrag', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __( 'Auto Play?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'loop',
            [
                'label' => __( 'Infinite Loop', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'true',
            ]
        );
        $this->add_control(
            'autoplaytimeout',
            [
                'label' => __( 'Autoplay Timeout', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'label_block' => true,
                'default' => '5000',
                'options' => [
                    '1000'  => __( '1 Second', 'busico-hp' ),
                    '2000'  => __( '2 Second', 'busico-hp' ),
                    '3000'  => __( '3 Second', 'busico-hp' ),
                    '4000'  => __( '4 Second', 'busico-hp' ),
                    '5000'  => __( '5 Second', 'busico-hp' ),
                    '6000'  => __( '6 Second', 'busico-hp' ),
                    '7000'  => __( '7 Second', 'busico-hp' ),
                    '8000'  => __( '8 Second', 'busico-hp' ),
                    '9000'  => __( '9 Second', 'busico-hp' ),
                    '10000' => __( '10 Second', 'busico-hp' ),
                    '11000' => __( '11 Second', 'busico-hp' ),
                    '12000' => __( '12 Second', 'busico-hp' ),
                    '13000' => __( '13 Second', 'busico-hp' ),
                    '14000' => __( '14 Second', 'busico-hp' ),
                    '15000' => __( '15 Second', 'busico-hp' ),
                ],
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]	
        );

        $this->add_control(
            'arrow_prev_icon',
            [
                'label' => __( 'Previous Icon', 'busico' ),
                'label_block' => false,
                'type' => \Elementor\Controls_Manager::ICONS,
                'skin' => 'inline',
                'default' => [
                    'value' => 'fas fa-chevron-left',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'arrow_next_icon',
            [
                'label' => __( 'Next Icon', 'busico' ),
                'label_block' => false,
                'type' => \Elementor\Controls_Manager::ICONS,
                'skin' => 'inline',
                'default' => [
                    'value' => 'fas fa-chevron-right',
                    'library' => 'fa-solid',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_image',
            [
                'label' => __('Image', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'image_hover_tabs'
        );
        $this->start_controls_tab(
            'image_normal_tab',
            [
                'label' => __('Normal', 'busico-hp'),
            ]
        );
        $this->add_responsive_control(
            'image_radius',
            [
                'label' => __('Image Radius', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    ' {{WRAPPER}} .busico-portfolio-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_shadow',
                'label' => __('Button Shadow', 'busico-hp'),
                'selector' => '{{WRAPPER}} .busico-portfolio-item img',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'label' => __('Border', 'busico-hp'),
                'selector' => '{{WRAPPER}} .busico-portfolio-item img',
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'image_hover_tab',
            [
                'label' => __('Hover', 'busico-hp'),
            ]
        );
        $this->add_responsive_control(
            'image_hover_radius',
            [
                'label' => __('Box Image Radius', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    ' {{WRAPPER}} .busico-portfolio-item:hover img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_hover_shadow',
                'label' => __('Button Shadow', 'busico-hp'),
                'selector' => '{{WRAPPER}} .busico-portfolio-item:hover img',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'image_hover_border',
                'label' => __('Border', 'busico-hp'),
                'selector' => '{{WRAPPER}} .busico-portfolio-item:hover img',
            ]
        );
        $this->add_control(
            'enable_hover_rotate',
            [
                'label' => __('Rotate animation on hover?', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'busico-hp'),
                'label_off' => __('No', 'busico-hp'),
                'return_value' => 'busico-hover-rotate',
                'default' => 'no',
            ]
        );
        
        $this->add_control(
            'image_hover_animation',
            [
                'label' => __('Hover Animation', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
                // 'prefix_class' => 'elementor-animation-',
                'condition' => [
                    'enable_hover_rotate!' => 'busico-hover-rotate'
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section(
            'section_title_style',
            [
                'label' => __('Title', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'title_style_tabs'
        );
        $this->start_controls_tab(
            'title_style_normal_tab',
            [
                'label' => __('Normal', 'busico-hp'),
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'label' => __('Title Typography', 'busico-hp'),
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .busico-portfolio-title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .busico-portfolio-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_align',
            [
                'label' => __('Align', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'flex-start' => __('Left', 'busico-hp'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __('top', 'busico-hp'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'busico-hp'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .busico-portfolio-content h3' => 'justify-content: {{VALUE}};',
                ],
                'toggle' => true,
            ]
        );
       
        $this->end_controls_tab();
        $this->start_controls_tab(
            'title_style_hover_tab',
            [
                'label' => __('Hover', 'busico-hp'),
            ]
        );
        $this->add_control(
            'title_color_hover',
            [
                'label' => __('Title Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .busico-portfolio-title:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
       
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_style',
            [
                'label' => __('Content Box', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
  
        $this->add_control(
            'content_bg_color',
            [
                'label' => __('Content Background Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .busico-portfolio-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'content_gap',
            [
                'label' => __('Content gap', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .busico-portfolio-content.content-postion-on-image' => 'left:{{SIZE}}{{UNIT}};right:{{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'content_y_position',
            [
                'label' => __('Content Y Position', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .busico-portfolio-content.content-postion-on-image' => 'bottom:{{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __('Content Padding', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .busico-portfolio-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_radius',
            [
                'label' => __('Content Box Radius', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .busico-portfolio-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


   /*
   * 
    Dots
   */
    $this->start_controls_section(
        'dots_navigation',
        [
            'label' => __('Navigation - Dots', 'busico-hp'),
            'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            'condition' => [
                'layout_type' => 'slider',
            ]
        ]
    );

    $this->add_control(
        'dots_color',
        [
            'label' => __('Color', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .busico-pf-gallery-slider-dots' => 'background-color: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'dots_color_active',
        [
            'label' => __('Active Color', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .busico-pf-gallery-slider-dots li.slick-active button' => 'background-color: {{VALUE}};',
            ],
        ]
    );


 

  
    $this->end_controls_section();

   /*
   * 
    Arrows
   */
    $this->start_controls_section(
        'arrows_navigation',
        [
            'label' => __('Navigation - Arrow', 'busico-hp'),
            'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            'condition' => [
                'layout_type' => 'slider',
            ]
        ]
    );

    $this->start_controls_tabs('_tabs_arrow');

    $this->start_controls_tab(
        '_tab_arrow_normal',
        [
            'label' => __('Normal', 'busico-hp'),
        ]
    );

    $this->add_control(
        'arrow_color',
        [
            'label' => __('Color', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .busico-pf-gallery-slider .slick-arrow i' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                '{{WRAPPER}} .busico-pf-gallery-slider .slick-arrow svg path' => 'stroke: {{VALUE}};',
            ],
        ]
    );
    
    $this->add_control(
        'arrow_color_fill',
        [
            'label' => __('Line Color', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .busico-pf-gallery-slider .slick-arrow i:vefore' => 'color: {{VALUE}};',
                '{{WRAPPER}} .busico-pf-gallery-slider .slick-arrow svg path' => 'fill: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'arrow_bg_color',
        [
            'label' => __('Background Color', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                 '{{WRAPPER}} .busico-pf-gallery-slider button.slick-arrow' => 'background-color: {{VALUE}} !important;',
            ],
        ]
    );
    
    $this->add_group_control(
        \Elementor\Group_Control_Box_Shadow::get_type(),
        [
            'name' => 'arrow_shadow',
            'label' => __('Shadow', 'fd-addons'),
            'selector' => '{{WRAPPER}} .busico-pf-gallery-slider button.slick-arrow',
        ]
    );

    $this->end_controls_tab();

    $this->start_controls_tab(
        '_tab_arrow_hover',
        [
            'label' => __('Hover', 'busico-hp'),
        ]
    );

    $this->add_control(
        'arrow_hover_color',
        [
            'label' => __('Color', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                 '{{WRAPPER}} .busico-pf-gallery-slider .slick-arrow:hover i:vefore' => 'color: {{VALUE}};',
                 '{{WRAPPER}} .busico-pf-gallery-slider .slick-arrow:hover svg path' => 'stroke: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'arrow_hover_fill_color',
        [
            'label' => __('Line Color', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                 '{{WRAPPER}} .busico-pf-gallery-slider .slick-arrow:hover i:vefore' => 'color: {{VALUE}};',
                 '{{WRAPPER}} .busico-pf-gallery-slider .slick-arrow:hover svg path' => 'fill: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'arrow_bg_hover_color',
        [
            'label' => __('Background Color Hover', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                 '{{WRAPPER}} .busico-pf-gallery-slider .busico-slick-next:hover, .busico-pf-gallery-slider .busico-slick-prev:hover' => 'background-color: {{VALUE}}  !important;',
            ],
        ]
    );


    $this->add_group_control(
        \Elementor\Group_Control_Box_Shadow::get_type(),
        [
            'name' => 'arrow_hover_shadow',
            'label' => __('Shadow Hover', 'fd-addons'),
            'selector' => '{{WRAPPER}} .busico-pf-gallery-slider .busico-slick-next:hover, {{WRAPPER}} .busico-pf-gallery-slider .busico-slick-prev:hover',
        ]
    );
    $this->end_controls_tab();
    $this->end_controls_tabs();

    $this->add_control(
        'hrthere',
        [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ]
    ); 

    $this->add_control(
        'arrow_position_toggle',
        [
            'label' => __('Position', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'label_off' => __('None', 'busico-hp'),
            'label_on' => __('Custom', 'busico-hp'),
            'return_value' => 'yes',
        ]
    );
    $this->start_popover();

    /* 
    Arrow Position
    */
    $this->add_responsive_control(
        'arrow_position_y',
        [
            'label' => __('Vertical', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['%','px'],
            'condition' => [
                'arrow_position_toggle' => 'yes'
            ],
            'range' => [
                'px' => [
                    'min' => -1000,
                    'max' => 1000,
                ],
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .busico-pf-gallery-slider button.slick-arrow' => 'bottom: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );

    $this->add_responsive_control(
        'arrow_prev_position',
        [
            'label' => __('Prev icon Position', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px', '%'],
            'condition' => [
                'arrow_position_toggle' => 'yes'
            ],
            'range' => [
                'px' => [
                    'min' => -2000,
                    'max' => 2000,
                ],
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                'body:not(.rtl) {{WRAPPER}} .busico-pf-gallery-slider .slick-arrow.busico-slick-prev' => 'left: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'arrow_nextv_position',
        [
            'label' => __('Next icon Position', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px', '%'],
            'condition' => [
                'arrow_position_toggle' => 'yes'
            ],
            'range' => [
                'px' => [
                    'min' => -2000,
                    'max' => 2000,
                ],
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                'body:not(.rtl) {{WRAPPER}} .busico-pf-gallery-slider .slick-arrow.busico-slick-next' => 'right: {{SIZE}}{{UNIT}}; left:auto;',
            ],
        ]
    );


    // $this->add_responsive_control(
    //     'arrow_position_right_gap',
    //     [
    //         'label' => __('Prev Aarrow Gap', 'busico-hp'),
    //         'type' => \Elementor\Controls_Manager::SLIDER,
    //         'size_units' => ['px'],
    //         'condition' => [
    //             'arrow_position_toggle' => 'yes'
    //         ],
    //         'range' => [
    //             'px' => [
    //                 'min' => -1000,
    //                 'max' => 2000,
    //             ],
    //         ],
    //         'selectors' => [
    //             'body:not(.rtl) {{WRAPPER}} .busico-pf-gallery-slider .slick-arrow.busico-slick-next' => 'right: {{SIZE}}{{UNIT}};',
    //             'body.rtl {{WRAPPER}} .busico-pf-gallery-slider .slick-arrow  button.busico-slick-prev' => 'left: {{SIZE}}{{UNIT}};',
    //         ],
    //     ]
    // );
    $this->end_popover();

    $this->add_responsive_control(
        'arrow_icon_size',
        [
            'label' => __('Icon Size', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => 10,
                    'max' => 150,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}}  .busico-pf-gallery-slider .slick-arrow i' => 'font-size: {{SIZE}}{{UNIT}}',
                '{{WRAPPER}}  .busico-pf-gallery-slider .slick-arrow svg' => 'width: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    
    $this->add_responsive_control(
        'arrow_size_box',
        [
            'label' => __('Size', 'busico-hp'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => 20,
                    'max' => 150,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .busico-pf-gallery-slider button.slick-arrow' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );
    $this->end_controls_section();
    }

    protected function get_render_icon($icon){
        ob_start();
        \Elementor\Icons_Manager::render_icon($icon, ['aria-hidden' => 'true']);
        return ob_get_clean();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings();
        $paged = get_query_var('paged') ? get_query_var('paged') : 1;
        $portfolio_data = [];
        $portfolio_data['settings'] = $this->get_settings();
        $portfolio_data = json_encode($portfolio_data);
        $post_grid_desktop = $settings['post_grid'];
        $post_grid_tablet  = $settings['post_grid_tablet'];
        $post_grid_mobile  = $settings['post_grid_mobile'];
        //this code slider option
        $slider_extraSetting = array(
            
            'next_icon' => $this->get_render_icon($settings['arrow_next_icon']),
            'prev_icon' => $this->get_render_icon($settings['arrow_prev_icon']),
            
            'loop' => (!empty($settings['loop']) && 'yes' === $settings['loop']) ? true : false,
            'dots' => (!empty($settings['dots']) && 'yes' === $settings['dots']) ? true : false,
            'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
            'nav' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,
            'mousedrag' => (!empty($settings['mousedrag']) && 'yes' === $settings['mousedrag']) ? true : false,
            'autoplaytimeout' => !empty($settings['autoplaytimeout']) ? $settings['autoplaytimeout'] : '5000',
            
            //this a responsive layout
            'per_coulmn' =>        (!empty($settings['per_coulmn'])) ? $settings['per_coulmn'] : 3,
            'per_coulmn_tablet' => (!empty($settings['per_coulmn_tablet'])) ? $settings['per_coulmn_tablet'] : 2,
            'per_coulmn_mobile' => (!empty($settings['per_coulmn_mobile'])) ? $settings['per_coulmn_mobile'] : 1
        );
        
        $jasondecode = wp_json_encode($slider_extraSetting);
        if('slider' == $settings['layout_type']){
            $this->add_render_attribute('pf_gallery_slide', 'data-settings', $jasondecode);
        }


?>
        <?php if('slider' == $settings['layout_type']):  ?>
            <div class="busico-pf-gallery-slider" <?php echo $this->get_render_attribute_string('pf_gallery_slide'); ?>>
                <?php 
                    $i = 0;
                    foreach (  $settings['gallery_list'] as $item ) : 
                        $image_size = ( $item['image_size']['width'] || $item['image_size']['height'] ) ? [$item['image_size']['width'] , $item['image_size']['height']] : 'full';
                    ?>
                        <div class="busico-portfolio-item" <?php //echo  $this->get_render_attribute_string( 'busico-gallery-lightbox-'.$i ) ; ?>>
                            <a href="<?php echo wp_get_attachment_image_url( $item['image']['id'], 'full'  ) ?>" class="busico-portfolio-image d-block <?php echo esc_attr('elementor-animation-'.$settings['image_hover_animation']) ?>">
                                <?php echo wp_get_attachment_image( $item['image']['id'], $image_size  ); ?>
                            </a>
                            <?php if(!empty($item['image_title'])):?>
                            <a href="<?php echo wp_get_attachment_image_url( $item['image']['id'], 'full'  ) ?>" class="busico-portfolio-content content-postion-on-image">
                                <h3 class="busico-portfolio-title">
                                    <?php echo esc_html( $item['image_title'] ) ?>
                                </h3>
                            </a>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                </div>

            <?php else: ?>

            <div class="row justify-content-center busico-pf-gallery-wrap layout-mode-<?php echo esc_attr($settings['layout_type'] . ' ' . $settings['enable_hover_rotate']) ?>">
                <?php 
                $i = 0;
                foreach (  $settings['gallery_list'] as $item ) : 
                    $i++;
                    $unique_id = rand(100, 10000);
                    $image_size = ( $item['image_size']['width'] || $item['image_size']['height'] ) ? [$item['image_size']['width'] , $item['image_size']['height']] : 'full';
                    if(!empty($item['image_grid'])){
                        $image_grid_desktop = $item['image_grid'];
                        $image_grid_tablet  = $item['image_grid_tablet'];
                        $image_grid_mobile  = $item['image_grid_mobile'];
                        $grid = sprintf('col-lg-%s col-md-%s col-%s', esc_attr($image_grid_desktop), esc_attr($image_grid_tablet), esc_attr($image_grid_mobile));   
                    }else{
                        $grid = sprintf('col-lg-%s col-md-%s col-%s', esc_attr($post_grid_desktop), esc_attr($post_grid_tablet), esc_attr($post_grid_mobile));    
                    }
                ?>
                <div class="busico-portfolio-item-wrap <?php echo esc_attr( $grid ) ?>"  >

                    <div class="busico-portfolio-item" <?php echo  $this->get_render_attribute_string( 'busico-gallery-lightbox-'.$i ) ; ?>>
                        <a href="<?php echo wp_get_attachment_image_url( $item['image']['id'], 'full'  ) ?>" class="busico-portfolio-image d-block <?php echo esc_attr('elementor-animation-'.$settings['image_hover_animation']) ?>">
                            <?php echo wp_get_attachment_image( $item['image']['id'], $image_size  ); ?>
                        </a>
                        <?php if(!empty($item['image_title'])):?>
                        <a href="<?php echo wp_get_attachment_image_url( $item['image']['id'], 'full'  ) ?>" class="busico-portfolio-content content-postion-on-image">
                            <h3 class="busico-portfolio-title">
                                <?php echo esc_html( $item['image_title'] ) ?>
                            </h3>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
         <?php endif;?>
<?php

    }
}

$widgets_manager->register_widget_type(new \Busico_Portfolio_Gallery());