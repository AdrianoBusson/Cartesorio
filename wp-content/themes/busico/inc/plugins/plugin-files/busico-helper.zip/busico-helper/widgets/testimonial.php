<?php
/**
 * busico-hp Testimonial Normal Widget.
 *
 *
 * @since 1.0.0
 */
use  Elementor\Widget_Base;
use  Elementor\Controls_Manager;
use  Elementor\utils;
use  Elementor\Group_Control_Typography;
use  Elementor\Group_Control_Box_Shadow;
use  Elementor\Group_Control_Background;
use  Elementor\Group_Control_Border;
use  Elementor\Repeater;
use  Elementor\Icons_Manager;

if (!defined('ABSPATH')) {
    exit;
}
// If this file is called directly, abort.
class Busico_Testimonail_Loop extends \Elementor\Widget_Base {
    public function get_name() {
        return 'busico-testimonial-loop';
    }

    public function get_title() {
        return __('Busico Testimonial', 'busico-hp');
    }

    public function get_icon() {
        return ('eicon-testimonial');
    }

    public function get_categories() {
        return ['busico-addons'];
    }

    public function get_script_depends()
    {
        return ['busico-addon'];
    }

    public function get_style_depends()
    {
        return ['owl-carousel', 'busico-addons'];
    }

    public function get_keywords() {
        return ['team', 'card', 'testimonial', 'membar', 'reviw', 'rating'];
    }

    protected function register_controls() {
        $this->start_controls_section('ts_section',
            [
                'label' => __('General', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
			'testimonial_version',
			[
				'label' => __( 'Select Style', 'busico-hp' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style-one',
				'options' => [
					'style-one'  => __( 'Style 01', 'busico-hp' ),
					'style-two' => __( 'Style 02', 'busico-hp' ),
				],
			]
		);
        $this->add_control(
            'show_quotes',
            [
                'label' => __('Show Quotes', 'busico-hp'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'busico-hp'),
                'label_off' => __('No', 'busico-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'show_slider_settings',
            [
                'label' => __('Slider Active', 'busico-hp'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'busico-hp'),
                'label_off' => __('No', 'busico-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'quotes_icon',
            [
                'label' => __('Quotes Icon', 'busico-hp'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-quote-left',
                    'library' => 'fa-solid',
                ],
                'condition' => [
                    'show_quotes' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();


        //Query
        $this->start_controls_section('query',
        [
            'label' => __('Query', 'busico-hp'),
            'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'item_per_page',
            [
                'label'       => __('Numbar Of Items', 'busico'),
                'type'        => Controls_Manager::NUMBER,
                'default'     => '',
                'description' => 'user emty value show all posts',
            ]
        );
        $this->add_control(
            'post_by',
            [
                'label' => __('Post By:', 'busico-hp'),
                'type' => Controls_Manager::SELECT,
                'default' => 'latest',
                'label_block' => true,
                'options' => array(
                    'latest'   =>   __('Latest Post', 'busico-hp'),
                    'selected' =>   __('Selected posts', 'busico-hp'),
                ),
            ]
        );
        $this->add_control(
            'post__in',
            [
                'label' => __('Post In', 'busico-hp'),
                'type' => Controls_Manager::SELECT2,
                'options' => busico_get_all_posts('busico_testimonial'),
                'multiple' => true,
                'label_block' => true,
                'condition'   => [
					'post_by' => 'selected',
				]
            ]
        );
        $this->add_control(
            'orderby',
            [
                'label' => __('Order By', 'busico-hp'),
                'type' => Controls_Manager::SELECT,
                'options' => busico_get_post_orderby_options(),
                'default' => 'date',
                'label_block' => true,

            ]
        );
        $this->add_control(
            'order',
            [
                'label' => __('Order', 'busico-hp'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => 'Ascending',
                    'desc' => 'Descending',
                ],
                'default' => 'desc',
                'label_block' => true,

            ]
        );
        $this->add_control(
            't_word_limit',
            [
                'label' => __('Testimonial Word Limit', 'busico-hp'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
            ]
        );
        $this->end_controls_section();


    //Slider Setting
    $this->start_controls_section('slider_settings',
        [
        'label' => __('Slider Settings', 'busico-hp'),
        'tab'   => Controls_Manager::TAB_CONTENT,
        'condition' => [
            'show_slider_settings' => 'yes',
        ]
        ]
    );
    $this->add_control(
        'arrows',
        [
            'label' => __( 'Show arrows?', 'busico-hp' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __( 'Show', 'busico-hp' ),
            'label_off' => __( 'Hide', 'busico-hp' ),
            'return_value' => 'yes',
            'default' => 'no',
        ]
    );


    $this->add_control(
        'mousedrag',
        [
            'label' => __( 'Show MouseDrag', 'busico-hp' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __( 'Show', 'busico-hp' ),
            'label_off' => __( 'Hide', 'busico-hp' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );

    $this->add_control(
        'autoplay',
        [
            'label' => __( 'Auto Play?', 'busico-hp' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __( 'Show', 'busico-hp' ),
            'label_off' => __( 'Hide', 'busico-hp' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );
    $this->add_control(
        'loop',
        [
            'label' => __( 'Infinite Loop', 'busico-hp' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __( 'Show', 'busico-hp' ),
            'label_off' => __( 'Hide', 'busico-hp' ),
            'return_value' => 'yes',
            'default' => 'true',
        ]
    );
    $this->add_control(
        'autoplaytimeout',
        [
            'label' => __( 'Autoplay Timeout', 'busico-hp' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'label_block' => true,
            'default' => '5000',
            'options' => [
                '1000'  => __( '1 Second', 'busico-hp' ),
                '2000'  => __( '2 Second', 'busico-hp' ),
                '3000'  => __( '3 Second', 'busico-hp' ),
                '4000'  => __( '4 Second', 'busico-hp' ),
                '5000'  => __( '5 Second', 'busico-hp' ),
                '6000'  => __( '6 Second', 'busico-hp' ),
                '7000'  => __( '7 Second', 'busico-hp' ),
                '8000'  => __( '8 Second', 'busico-hp' ),
                '9000'  => __( '9 Second', 'busico-hp' ),
                '10000' => __( '10 Second', 'busico-hp' ),
                '11000' => __( '11 Second', 'busico-hp' ),
                '12000' => __( '12 Second', 'busico-hp' ),
                '13000' => __( '13 Second', 'busico-hp' ),
                '14000' => __( '14 Second', 'busico-hp' ),
                '15000' => __( '15 Second', 'busico-hp' ),
            ],
            'condition' => [
                'autoplay' => 'yes',
            ],
        ]
    );

    $this->add_control(
        'arrow_prev_icon',
        [
            'label' => __( 'Previous Icon', 'busico' ),
            'label_block' => false,
            'type' => \Elementor\Controls_Manager::ICONS,
            'skin' => 'inline',
            'default' => [
                'value' => 'fas fa-chevron-left',
                'library' => 'fa-solid',
            ],
            'condition' => [
                'arrows' => 'yes',
            ],
        ]
    );

    $this->add_control(
        'arrow_next_icon',
        [
            'label' => __( 'Next Icon', 'busico' ),
            'label_block' => false,
            'type' => \Elementor\Controls_Manager::ICONS,
            'skin' => 'inline',
            'default' => [
                'value' => 'fas fa-chevron-right',
                'library' => 'fa-solid',
            ],
            'condition' => [
                'arrows' => 'yes',
            ],
        ]
    );

    
    $this->end_controls_section();

    //iamge
    $this->start_controls_section('iamge_style',
        [
            'label' => __('Image', 'busico-hp'),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_responsive_control(
        'width',
        [
            'label'          => __('Width', 'busico-hp'),
            'type'           => Controls_Manager::SLIDER,
            'default'        => [
                'unit' => 'px',
            ],
            'tablet_default' => [
                'unit' => 'px',
            ],
            'mobile_default' => [
                'unit' => 'px',
            ],
            'size_units'     => ['px', '%', 'vw'],
            'range'          => [
                '%'  => [
                    'min' => 1,
                    'max' => 100,
                ],
                'px' => [
                    'min' => 1,
                    'max' => 1000,
                ],
                'vw' => [
                    'min' => 1,
                    'max' => 100,
                ],
            ],
            'selectors'      => [
                '{{WRAPPER}} .busico-single-testimonial-item .busico-client-img' => 'width: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );

    $this->add_responsive_control(
        'space',
        [
            'label'          => __('Max Width', 'busico-hp'),
            'type'           => Controls_Manager::SLIDER,
            'default'        => [
                'unit' => 'px',
            ],
            'tablet_default' => [
                'unit' => 'px',
            ],
            'mobile_default' => [
                'unit' => 'px',
            ],
            'size_units'     => ['px', '%', 'vw'],
            'range'          => [
                '%'  => [
                    'min' => 1,
                    'max' => 100,
                ],
                'px' => [
                    'min' => 1,
                    'max' => 1000,
                ],
                'vw' => [
                    'min' => 1,
                    'max' => 100,
                ],
            ],
            'selectors'      => [
                '{{WRAPPER}} .busico-single-testimonial-item .busico-client-img' => 'max-width: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );
    $this->add_responsive_control(
        'height',
        [
            'label'          => __('Height', 'busico-hp'),
            'type'           => Controls_Manager::SLIDER,
            'default'        => [
                'unit' => 'px',
            ],
            'tablet_default' => [
                'unit' => 'px',
            ],
            'mobile_default' => [
                'unit' => 'px',
            ],
            'size_units'     => ['px', 'vh'],
            'range'          => [
                'px' => [
                    'min' => 1,
                    'max' => 500,
                ],
                'vh' => [
                    'min' => 1,
                    'max' => 100,
                ],
            ],
            'selectors'      => [
                '{{WRAPPER}} .busico-single-testimonial-item .busico-client-img' => 'height: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );

    $this->add_responsive_control(
        'object-fit',
        [
            'label'     => __('Object Fit', 'busico-hp'),
            'type'      => Controls_Manager::SELECT,
            'condition' => [
                'height[size]!' => '',
            ],
            'options'   => [
                ''        => __('Default', 'busico-hp'),
                'fill'    => __('Fill', 'busico-hp'),
                'cover'   => __('Cover', 'busico-hp'),
                'contain' => __('Contain', 'busico-hp'),
            ],
            'default'   => 'cover',
            'selectors' => [
                '{{WRAPPER}} .bg-cover' => 'background-position: {{VALUE}};',
            ],
        ]
    );
    $this->add_group_control(
        Group_Control_Border::get_type(),
        [
            'name'      => 'image_border',
            'selector'  => '{{WRAPPER}} .busico-single-testimonial-item .busico-client-img',
            'separator' => 'before',
        ]
    );
    $this->add_responsive_control(
        'image_border_radius',
        [
            'label'      => __('Border Radius', 'busico-hp'),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors'  => [
                '{{WRAPPER}} .busico-single-testimonial-item .busico-client-img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                'body.rtl {{WRAPPER}} .busico-single-testimonial-item .busico-client-img' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}} !important;;',
            ],
        ]
    );

    $this->add_responsive_control(
        'image_margin',
        [
            'label'      => __('Margin', 'busico-hp'),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors'  => [
                '{{WRAPPER}} .busico-single-testimonial-item .busico-client-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                'body.rtl {{WRAPPER}} .busico-single-testimonial-item .busico-client-img' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
            ],
        ]
    );
    $this->add_group_control(
        Group_Control_Box_Shadow::get_type(),
        [
            'name'     => 'image_box_shadow',
            'exclude'  => [
                'box_shadow_position',
            ],
            'selector' => '{{WRAPPER}} .busico-single-testimonial-item .busico-client-img',
        ]
    );
    $this->end_controls_section();


    // Name
    $this->start_controls_section('tn_name',
        [
            'label' => __('Name', 'busico-hp'),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_control(
        'name_color',
        [
            'label'     => __('Color', 'busico-hp'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .busico-single-testimonial-item .busico-client-info h5' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_control(
        'name_color_hover',
        [
            'label'     => __('Hover Color', 'busico-hp'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .busico-single-testimonial-item:hover .busico-single-testimonial-item .busico-client-info h5' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name'     => 'name_typo',
            'label'    => __('Typography', 'busico-hp'),
            'selector' => '{{WRAPPER}}  .busico-single-testimonial-item .busico-client-info h5',
        ]
    );
    $this->add_responsive_control(
        'name_margin',
        [
            'label'      => __('Margin', 'busico-hp'),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => ['px'],
            'selectors'  => [
                '{{WRAPPER}} .busico-single-testimonial-item .busico-client-info h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                'body.rtl {{WRAPPER}} .busico-single-testimonial-item .busico-client-info h5' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
            ],
        ]
    );
    $this->end_controls_section();

    // Title
    $this->start_controls_section('tn_title',
        [
            'label' => __('Designation', 'busico-hp'),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_control(
        'title_color',
        [
            'label'     => __('Color', 'busico-hp'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .busico-single-testimonial-item .busico-client-info span' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_control(
        'title_color_hover',
        [
            'label'     => __('Hover Color', 'busico-hp'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .busico-single-testimonial-item:hover .busico-single-testimonial-item .busico-client-info span' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name'     => 'title_typo',
            'label'    => __('Typography', 'busico-hp'),
            'selector' => '{{WRAPPER}}  .busico-single-testimonial-item .busico-client-info span',
        ]
    );

    $this->add_responsive_control(
        'title_margin',
        [
            'label'      => __('Margin', 'busico-hp'),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors'  => [
                '{{WRAPPER}} .busico-single-testimonial-item .busico-client-info span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                'body.rtl {{WRAPPER}} .busico-single-testimonial-item .busico-client-info span' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
            ],
        ]
    );
    $this->end_controls_section();

    // Discription
    $this->start_controls_section('discription',
        [
            'label' => __('Discription', 'busico-hp'),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_control(
        'dis_color',
        [
            'label'     => __('Color', 'busico-hp'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .busico-single-testimonial-item p' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_control(
        'dis_color_hover',
        [
            'label'     => __('Hover Color', 'busico-hp'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .busico-single-testimonial-item:hover .busico-single-testimonial-item p' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name'     => 'dis_typo',
            'label'    => __('Typography', 'busico-hp'),
            'selector' => '{{WRAPPER}}  .busico-single-testimonial-item p',
        ]
    );

    $this->add_responsive_control(
        'dis_margin',
        [
            'label'      => __('Margin', 'busico-hp'),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors'  => [
                '{{WRAPPER}} .busico-single-testimonial-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                'body.rtl {{WRAPPER}} .busico-single-testimonial-item p' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
            ],
        ]
    );

    $this->end_controls_section();

    //Quate
    $this->start_controls_section('quate_style',
        [
            'label' => __('Quote', 'busico-hp'),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
     );

    $this->add_control(
        'quate_color',
        [
            'label'     => __('Color', 'busico-hp'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .busico-single-testimonial-item::before' => 'color: {{VALUE}}',
                '{{WRAPPER}} .busico-testimonial__quotes-icon svg' => 'color: {{VALUE}}',
                '{{WRAPPER}} .busico-testimonial__quotes-icon svg path' => 'fill: {{VALUE}}',
                '{{WRAPPER}} .busico-testimonial__quotes-icon svg i' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'quate_bg_color',
        [
            'label'     => __('Background Color', 'busico-hp'),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .busico-single-testimonial-item::before' => 'background-color: {{VALUE}}',
                '{{WRAPPER}} .busico-testimonial__quotes-icon svg' => 'background-color: {{VALUE}}',
            ],
        ]
    );

   

    $this->add_control(
        'hr1',
        [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ]
    );

    $this->add_responsive_control(
        'quate_size',
        [
            'label'          => __('Font Size', 'busico-hp'),
            'type'           => Controls_Manager::SLIDER,
            'default'        => [
                'unit' => 'px',
            ],
            'range'          => [
                'px' => [
                    'min' => 1,
                    'max' => 100,
                ],
            ],
            'selectors'      => [
                '{{WRAPPER}} .busico-single-testimonial-item::before' => 'font-size: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .busico-testimonial__quotes-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .busico-testimonial__quotes-icon svg' => 'width: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'quate_box_size',
        [
            'label'          => __('Quate Box Size', 'busico-hp'),
            'type'           => Controls_Manager::SLIDER,
            'default'        => [
                'unit' => 'px',
            ],
            'range'          => [
                'px' => [
                    'min' => 1,
                    'max' => 100,
                ],
            ],
            'selectors'      => [
                '{{WRAPPER}} .busico-single-testimonial-item::before' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}',
                '{{WRAPPER}} .busico-testimonial__quotes-icon' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this->add_group_control(
        Group_Control_Border::get_type(),
        [
            'name'      => 'quate_border',
            'selector'  => '{{WRAPPER}} .busico-single-testimonial-item::before',
            'selector'  => '{{WRAPPER}} .busico-testimonial__quotes-icon::before',
        ]
    );
    $this->add_responsive_control(
        'quate_border_radius',
        [
            'label'      => __('Border Radius', 'busico-hp'),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => ['px'],
            'selectors'  => [
                '{{WRAPPER}} .busico-single-testimonial-item::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .busico-testimonial__quotes-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );

    $this->add_responsive_control(
        'quate_margin',
        [
            'label'      => __('Margin', 'busico-hp'),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => ['px'],
            'selectors'  => [
                '{{WRAPPER}} .busico-single-testimonial-item::before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .busico-testimonial__quotes-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                
            ],
        ]
    );
    $this->end_controls_section();


        /*
        *
        Arrows
        */
        $this->start_controls_section(
            'arrows_navigation',
            [
                'label' => __('Navigation - Arrow', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'arrows' => 'yes',
                ],
            ]
        );
        $this->start_controls_tabs('_tabs_arrow');

        $this->start_controls_tab(
            '_tab_arrow_normal',
            [
                'label' => __('Normal', 'busico-hp'),
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div svg path' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_color_fill',
            [
                'label' => __('Line Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg_color',
            [
                'label' => __('Background Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => "#222",
                'selectors' => [
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrow_shadow',
                'label' => __('Shadow', 'fd-addons'),
                'selector' => '{{WRAPPER}} .testimonial-carousel-active .owl-nav div ',
            ]
        );

        $this->add_responsive_control(
            'arrow_icon_size',
            [
                'label' => __('Icon Size', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .testimonial-carousel-active .owl-nav div i' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}}  .testimonial-carousel-active .owl-nav div svg' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrow_size_box',
            [
                'label' => __('Size', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}',
                ],
            ]

        );

        $this->add_responsive_control(
            'arrow_size_line_height',
            [
                'label' => __('Line Height', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div' => 'line-height: {{SIZE}}{{UNIT}} !important;',
                ],
            ]

        );

        $this->add_responsive_control(
            'arrows_border_radius',
            [
                'label'      => __('Border Radius', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .testimonial-carousel-active .owl-nav div ' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            '_tab_arrow_hover',
            [
                'label' => __('Hover', 'busico-hp'),
            ]
        );

        $this->add_control(
            'arrow_hover_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div:hover ' => 'color: {{VALUE}} !important;',
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div:hover svg path ' => 'stroke: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_control(
            'arrow_hover_fill_color',
            [
                'label' => __('Line Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div:hover ' => 'color: {{VALUE}} !important;',
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div:hover path' => 'fill: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg_hover_color',
            [
                'label' => __('Background Color Hover', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-carousel-active .owl-nav div:hover ' => 'background-color: {{VALUE}}  !important;',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            '_tab_arrow_active',
            [
                'label' => __('Active', 'busico-hp'),
            ]
        );

        $this->add_control(
            'arrow_active_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-slider-arrow .slick-active' => 'color: {{VALUE}} !important;;',
                    '{{WRAPPER}} .testimonial-slider-arrow .slick-active svg path' => 'stroke: {{VALUE}} !important;;',
                ],
            ]
        );

        $this->add_control(
            'arrow_active_fill_color',
            [
                'label' => __('Line Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-slider-arrow .slick-active' => 'color: {{VALUE}} !important;;',
                    '{{WRAPPER}} .testimonial-slider-arrow .slick-active path' => 'fill: {{VALUE}} !important;;',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg_active_color',
            [
                'label' => __('Background Color Hover', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-slider-arrow .slick-active ' => 'background-color: {{VALUE}}  !important;',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();



/* end arrow */

    //Box Style
     $this->start_controls_section('ts_style',
        [
            'label' => __('Box', 'busico-hp'),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
     );

     $this->start_controls_tabs(
         'style_tabs'
     );
     // normal
     $this->start_controls_tab(
         'tn_bg_color',
         [
             'label' => __('Normal', 'busico-hp'),
         ]
     );

     $this->add_control(
         'bg',
         [
             'label'     => __('Backround Color', 'busico-hp'),
             'type'      => Controls_Manager::COLOR,
             'selectors' => [
                 '{{WRAPPER}} .busico-single-testimonial-item' => 'background-color: {{VALUE}}',
             ],
         ]
     );
     $this->add_group_control(
         Group_Control_Border::get_type(),
         [
             'name'      => 'tn_border',
             'selector'  => '{{WRAPPER}} .busico-single-testimonial-item',
         ]
     );

     $this->add_group_control(
         Group_Control_Box_Shadow::get_type(),
         [
             'name'     => 'tn_shadow',
             'exclude'  => [
                 'box_shadow_position',
             ],
             'selector' => '{{WRAPPER}} .busico-single-testimonial-item',
         ]
     );
     $this->add_responsive_control(
        'align',
        [
            'label' => __( 'Alignment', 'busico-hp' ),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __( 'Left', 'busico-hp' ),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __( 'Center', 'busico-hp' ),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __( 'Right', 'busico-hp' ),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'left',
            'selectors' => [
                '{{WRAPPER}} .busico-single-testimonial-item' => 'text-align: {{VALUE}} !important;',
            ],
        ]
    );

    $this->add_responsive_control(
        'margin_bottom',
        [
            'label'          => __('Bottom Gap', 'busico-hp'),
            'type'           => Controls_Manager::SLIDER,
            'size_units' => ['px', '%'],
            'default'        => [
                'unit' => 'px',
            ],
            'range'          => [
                'px' => [
                    'min' => 1,
                    'max' => 100,
                ],
            ],
            'selectors'      => [
                '{{WRAPPER}} .busico-single-testimonial-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
            ],
        ]
    );


    $this->add_responsive_control(
         'box_margin',
         [
             'label'      => __('Margin', 'busico-hp'),
             'type'       => Controls_Manager::DIMENSIONS,
             'size_units' => ['px', '%'],
             'selectors'  => [
                 '{{WRAPPER}} .busico-single-testimonial-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 '{{WRAPPER}} .slick-list' => 'margin: 0 -{{RIGHT}}{{UNIT}} 0 -{{LEFT}}{{UNIT}};',

             ],
         ]
     );

    $this->add_responsive_control(
         'box_padding',
         [
             'label'      => __('Padding', 'busico-hp'),
             'type'       => Controls_Manager::DIMENSIONS,
             'size_units' => ['px', '%'],
             'selectors'  => [
                 '{{WRAPPER}} .busico-single-testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 'body.rtl {{WRAPPER}} .busico-single-testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
             ],
         ]
     );

     $this->add_responsive_control(
         'border_radius',
         [
             'label'      => __('Border Radius', 'busico-hp'),
             'type'       => Controls_Manager::DIMENSIONS,
             'size_units' => ['px', '%'],
             'selectors'  => [
                 '{{WRAPPER}} .busico-single-testimonial-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 'body.rtl {{WRAPPER}} .busico-single-testimonial-item' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
             ],
         ]
     );

     $this->end_controls_tab();

     // hover
     $this->start_controls_tab(
         'bg_color_hover',
         [
             'label' => __('Hover', 'busico-hp'),
         ]
     );

     $this->add_control(
         'bg_hover',
         [
             'label'     => __('Backround Color', 'busico-hp'),
             'type'      => Controls_Manager::COLOR,
             'selectors' => [
                 '{{WRAPPER}} .busico-single-testimonial-item:hover' => 'background-color: {{VALUE}}',
             ],
         ]
     );
     $this->add_group_control(
         Group_Control_Border::get_type(),
         [
             'name'      => 'tn_border_hover',
             'selector'  => '{{WRAPPER}} .busico-single-testimonial-item:hover',
         ]
     );

     $this->add_group_control(
         Group_Control_Box_Shadow::get_type(),
         [
             'name'     => 'tn_shadow_hover',
             'exclude'  => [
                 'box_shadow_position',
             ],
             'selector' => '{{WRAPPER}} .busico-single-testimonial-item:hover',
         ]
     );

     $this->add_responsive_control(
         'border_radius_hover',
         [
             'label'      => __('Border Radius', 'busico-hp'),
             'type'       => Controls_Manager::DIMENSIONS,
             'size_units' => ['px', '%'],
             'selectors'  => [
                 '{{WRAPPER}} .busico-single-testimonial-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                 'body.rtl {{WRAPPER}} .busico-single-testimonial-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
             ],
         ]
     );
     $this->end_controls_tab();
     $this->end_controls_tabs();

    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $numabr_of_item = !empty($settings['item_per_page']) ? $settings['item_per_page'] : -1;

         $testimonial_version = $settings['testimonial_version'];




         //this code slider option
		$slider_extraSetting = array(

	        'loop' => (!empty($settings['loop']) && 'yes' === $settings['loop']) ? true : false,
	        'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
            'nav' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,
            'mousedrag' => (!empty($settings['mousedrag']) && 'yes' === $settings['mousedrag']) ? true : false,
        	'autoplaytimeout' => !empty($settings['autoplaytimeout']) ? $settings['autoplaytimeout'] : '5000',
        );

        $jasondecode = wp_json_encode($slider_extraSetting);

        if ( ( 'yes' == $settings['show_slider_settings'] ) ) {
            $this->add_render_attribute('testimonail_version', 'class', array('testimonial-carousel-active', 'owl-carousel' ));
            $this->add_render_attribute('testimonail_version', 'data-settings', $jasondecode);
        }

        $query_args = [
            'post_type'           => 'busico_testimonial',
            'orderby' => $settings['orderby'],
            'order'   => $settings['order'],
            'posts_per_page'      => $numabr_of_item,
            'post_status'         => 'publish',
            'ignore_sticky_posts' => 1,
        ];

        // get_type
        if ( 'selected' === $settings['post_by'] ) {
            $query_args['post__in'] = (array)$settings['post__in'];
        }

        $t_loop = new \WP_Query($query_args);


        ?>

        <div class="busico--tn-wraper">
            <div <?php echo $this->get_render_attribute_string('testimonail_version'); ?>>

               <?php while($t_loop->have_posts() ): $t_loop->the_post();
               $content = ($settings['t_word_limit']['size']) ? wp_trim_words(get_the_excerpt(), $settings['t_word_limit']['size'], '') : get_the_excerpt();
               ?>

                <?php if ($testimonial_version) {
                    include('testimonial/' . $testimonial_version . '.php');
                } ?>
                           
            <?php endwhile; wp_reset_postdata();?>


        </div>

    </div>
<?php
}
}
$widgets_manager->register_widget_type(new \Busico_Testimonail_Loop());