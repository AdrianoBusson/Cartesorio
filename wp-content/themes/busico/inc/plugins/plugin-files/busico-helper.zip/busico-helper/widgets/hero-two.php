<?php
/**
 * busico Image Carousel.
 *
 *
 * @since 1.0.0
 */
use  Elementor\Widget_Base;
use  Elementor\Controls_Manager;
use  Elementor\utils;
use  Elementor\Group_Control_Typography;
use  Elementor\Group_Control_Box_Shadow;
use  Elementor\Group_Control_Background;
use  Elementor\Group_Control_Border;
use  Elementor\Embed;
use  Elementor\Icons_Manager;
use  Elementor\Repeater;
if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Busico_Hero_Two extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'busico-hero-two';
    }

    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Hero Section Two', 'busico-hp');
    }

    public function get_keywords(){
        return ['iamge ', 'carousel','hero one', 'slider' ];
    }

    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-image-rollover';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['busico-addons'];
    }

    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */


    protected function register_controls()
    {
        /**
         * ==================================== Content Tab ========================================
         */
        $this->start_controls_section(
            'h2_content_section',
            [
                'label' => __('Content', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'h_bg_image',
            [
                'label'       => __( 'Background Image', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::MEDIA,
            ]
        );
        $repeater->add_control(
            'h_title',
            [
                'label'       => __( 'Title', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __('we make Dream home', 'busico-hp'),
            ]
        );

        $repeater->add_control(
            'h_discription',
            [
                'label'       => __( 'Short Discription', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __('Busico is a construction and architecture environmentally most responsible for any kinds of themes.', 'busico-hp'),
            ]
        );

        $repeater->add_control(
			'h2_btn_one',
			[
				'label' => __( 'Button One', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
        $repeater->add_control(
            'h2_btn_one_text',
            [
                'label'       => __( 'Button Text', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __('contact us ', 'busico-hp'),
            ]
        );
        $repeater->add_control(
            'h2_btn_one_url',
            [
                'label'       => __( 'Button Url', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::URL,
                'label_block' => true,
            ]
        );


        $repeater->add_control(
			'h2_btn_two',
			[
				'label' => __( 'Button Two', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);

        $repeater->add_control(
            'h2_btn_two_text',
            [
                'label'       => __( 'Button Text', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __('our portfolio', 'busico-hp'),
            ]
        );
        $repeater->add_control(
            'h2_btn_two_url',
            [
                'label'       => __( 'Button Url', 'busico-hp' ),
                'type'        => \Elementor\Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        // End Repeater Control field
        $this->add_control(
            'h2_contents',
            [
                'label' => __( 'Repeater List', 'omega-hp' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(h_title.slice(0,1).toUpperCase() + h_title.slice(1)) #>',
            ]
        );

        $this->end_controls_section();
		
		
		$this->start_controls_section('content_style_background',
            [
            'label' => __('Container', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'background_gradient_color',
				'types'     => [ 'classic', 'gradient' ],
				'fields_options'  => [
					'background'  => [
						'default' => 'classic'
					],
				],
				'selector'  => '{{WRAPPER}} .hero-2 .single-slide::before, .hero-2 .single-slide::after',
			]
		);
		$this->end_controls_section();
		
		
        // ===============================Content Style tab =====================================

        $this->start_controls_section('content_style',
            [
            'label' => __('Contents', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'contnet_box_margin',
            [
                'label'      => __('Content Wraper Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-2 .hero-contents' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-2 .hero-contents' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'contnet_box_padding',
            [
                'label'      => __('Content Wraper Padding', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-2 .hero-contents' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-2 .hero-contents' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        // =================================== Title ==========================================
        $this->add_control(
			'title_h2',
			[
				'label' => __( 'Title', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
        $this->add_control(
            'h2_title_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-contents h1' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'h2_title_typo',
                'label'    => __('Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}} .hero-contents h1',
            ]
        );
        $this->add_responsive_control(
            'h2_title_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-contents h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-contents h1' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        // =============================== Sub Title  ==========================================
        $this->add_control(
			'h2_sub_title',
			[
				'label' => __( 'Sub Title', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
        $this->add_control(
            'h2_sub_title_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .hero-contents h2' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'h2_sub_title_typo',
                'label'    => __('Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}}  .hero-contents h2',
            ]
        );
        $this->add_responsive_control(
            'h2_sub_title_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}}  .hero-contents h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}}  .hero-contents h2' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        //=================================== Discription ==================================
        $this->add_control(
			'h2_dis_title',
			[
				'label' => __( 'Discription', 'busico-hp' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
        $this->add_control(
            'h2_dis_title_color',
            [
                'label'     => __('Color', 'busico-hp'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .hero-contents p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'dis_title_typo',
                'label'    => __('Typography', 'busico-hp'),
                'selector' => '{{WRAPPER}} .hero-2 .hero-contents p',
            ]
        );
        $this->add_responsive_control(
            'h2_dis_title_margin',
            [
                'label'      => __('Margin', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-2 .hero-contents p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-2 .hero-contents p' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //=========================  Button Style One =========================================
        $this->start_controls_section(
            'h2_button_style',
            [
                'label' => __( 'Button One', 'busico-hp' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'h2_button_style_tabs'
        );

        $this->start_controls_tab(
            'h2_button_style_normal_tab',
            [
                'label' => __( 'Normal', 'busico-hp' ),
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'h2_btn_typography',
                'label'    => __( 'Typography', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one',
            ]
        );
        $this->add_control(
            'h2_boxed_btn_color',
            [
                'label'     => __( 'Button Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'h2_boxed_btn_background',
            [
                'label'     => __( 'Background Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'h2_button_border',
                'label'    => __( 'Border', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'h2_button_shadow',
                'label'    => __( 'Button Shadow', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .busico-btn',
            ]
        );
        $this->add_responsive_control(
            'h2_button_radius',
            [
                'label'      => __( 'Border Radius', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-btn'          => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-btn' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}}
                    ;',
                ],
            ]
        );
        $this->add_responsive_control(
            'h2_button_margin',
            [
                'label'      => __( 'Button Margin', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-btn'          => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-btn' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'h2_button_padding',
            [
                'label'      => __( 'Button Padding', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .busico-btn'          => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .busico-btn' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

          //===================== Button One Hover ===============================================

        $this->start_controls_tab(
            'h2_button_style_hover_tab',
            [
                'label' => __( 'Hover', 'busico-hp' ),
            ]
        );
        $this->add_control(
            'h2_btn_hover_color',
            [
                'label'     => __( 'Button Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'h2_btn_hover_bg_color',
            [
                'label'     => __( 'Background Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'h2_button_hover_border',
                'label'    => __( 'Border', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one:hover',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'h2_button_hover_shadow',
                'label'    => __( 'Button Shadow', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one:hover',
            ]
        );
        $this->add_responsive_control(
            'h2_button_hover_radius',
            [
                'label'      => __( 'Border Radius', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one:hover'          => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-one:hover' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}}
                    ;',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        // =================================  Button Two Style =================================
        $this->start_controls_section(
            'h2_button_style_two',
            [
                'label' => __( 'Button Two', 'busico-hp' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'h2_button_style_tabs_two'
        );

        $this->start_controls_tab(
            'h2_button_style_normal_tab_two',
            [
                'label' => __( 'Normal', 'busico-hp' ),
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'h2_btn_typography_two',
                'label'    => __( 'Typography', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two',
            ]
        );
        $this->add_control(
            'h2_boxed_btn_color_two',
            [
                'label'     => __( 'Button Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'h2_boxed_btn_background_two',
            [
                'label'     => __( 'Background Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'h2_button_border_two',
                'label'    => __( 'Border', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'h2_button_shadow_two',
                'label'    => __( 'Button Shadow', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two',
            ]
        );
        $this->add_responsive_control(
            'h2_button_radius_two',
            [
                'label'      => __( 'Border Radius', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two'          => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}}
                    ;',
                ],
            ]
        );
        $this->add_responsive_control(
            'h2_button_margin_two',
            [
                'label'      => __( 'Button Margin', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two'          => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'h2_button_padding_two',
            [
                'label'      => __( 'Button Padding', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two'          => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-2 .hero-contents .theme-btn.btn-two' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
           // ======================== Button Two Hover ========================================
        $this->start_controls_tab(
            'h2_button_style_hover_tab_two',
            [
                'label' => __( 'Hover', 'busico-hp' ),
            ]
        );
        $this->add_control(
            'h2_btn_hover_color_two',
            [
                'label'     => __( 'Button Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-btn.btn-two:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'h2_btn_hover_bg_color_two',
            [
                'label'     => __( 'Background Color', 'busico-hp' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-btn.btn-two:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'h2_button_hover_border_two',
                'label'    => __( 'Border', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .theme-btn.btn-two:hover',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'h2_button_hover_shadow_two',
                'label'    => __( 'Button Shadow', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .theme-btn.btn-two:hover',
            ]
        );
        $this->add_responsive_control(
            'h2_button_hover_radius_two',
            [
                'label'      => __( 'Border Radius', 'busico-hp' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .theme-btn.btn-two:hover'          => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .theme-btn.btn-two:hover' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}}
                    ;',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /*
        *
        ================================== Arrow style =======================
        */
        $this->start_controls_section(
            'arrows_navigation',
            [
                'label' => __('Navigation - Arrow', 'busico-hp'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('_tabs_arrow');

        $this->start_controls_tab(
            '_tab_arrow_normal',
            [
                'label' => __('Normal', 'busico-hp'),
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .owl-theme .owl-nav div i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg_color',
            [
                'label' => __('Background Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .owl-theme .owl-nav div' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'arrow_border',
                'label'    => __( 'Border', 'busico-hp' ),
                'selector' => '{{WRAPPER}} .hero-2 .owl-theme .owl-nav div',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrow_shadow',
                'label' => __('Shadow', 'fd-addons'),
                'selector' => '{{WRAPPER}} .hero-2 .owl-theme .owl-nav div',
            ]
        );

        $this->add_responsive_control(
            'arrow_icon_size',
            [
                'label' => __('Icon Size', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .hero-2 .owl-theme .owl-nav div i' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrow_size_box',
            [
                'label' => __('Size', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [ 
                        'min' => 20,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .owl-theme .owl-nav div' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}',
                ],
            ]

        );

        $this->add_responsive_control(
            'arrows_border_radius',
            [
                'label'      => __('Border Radius', 'busico-hp'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .hero-2 .owl-theme .owl-nav div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .hero-2 .owl-theme .owl-nav div' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

            //==============================Arrow Hover Style =============================

        $this->start_controls_tab(
            '_tab_arrow_hover',
            [
                'label' => __('Hover', 'busico-hp'),
            ]
        );

        $this->add_control(
            'arrow_hover_color',
            [
                'label' => __('Color', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .owl-theme .owl-nav div i:hover ' => 'color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg_hover_color',
            [
                'label' => __('Background Color Hover', 'busico-hp'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-2 .owl-theme .owl-nav div i:hover ' => 'background-color: {{VALUE}}  !important;',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        // Slider Option
        $this->start_controls_section('slider_settings',
            [
            'label' => __('Slider Settings', 'busico-hp'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'arrows',
            [
                'label' => __( 'Show arrows?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'mousedrag',
            [
                'label' => __( 'MouseDrag?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __( 'Auto Play?', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'loop',
            [
                'label' => __( 'Infinite Loop', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'busico-hp' ),
                'label_off' => __( 'Hide', 'busico-hp' ),
                'return_value' => 'yes',
                'default' => 'true',
            ]
        );
        $this->add_control(
            'autoplaytimeout',
            [
                'label' => __( 'Autoplay Timeout', 'busico-hp' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'label_block' => true,
                'default' => '5000',
                'options' => [
                    '1000'  => __( '1 Second', 'busico-hp' ),
                    '2000'  => __( '2 Second', 'busico-hp' ),
                    '3000'  => __( '3 Second', 'busico-hp' ),
                    '4000'  => __( '4 Second', 'busico-hp' ),
                    '5000'  => __( '5 Second', 'busico-hp' ),
                    '6000'  => __( '6 Second', 'busico-hp' ),
                    '7000'  => __( '7 Second', 'busico-hp' ),
                    '8000'  => __( '8 Second', 'busico-hp' ),
                    '9000'  => __( '9 Second', 'busico-hp' ),
                    '10000' => __( '10 Second', 'busico-hp' ),
                    '11000' => __( '11 Second', 'busico-hp' ),
                    '12000' => __( '12 Second', 'busico-hp' ),
                    '13000' => __( '13 Second', 'busico-hp' ),
                    '14000' => __( '14 Second', 'busico-hp' ),
                    '15000' => __( '15 Second', 'busico-hp' ),
                ],
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();



        // Slider Option
    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $contents =  $settings['h2_contents'];

         // Slider Option
         $slider_extraSetting = array(
	        'loop' => (!empty($settings['loop']) && 'yes' === $settings['loop']) ? true : false,
	        'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
        	'nav' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,
        	'mousedrag' => (!empty($settings['mousedrag']) && 'yes' === $settings['mousedrag']) ? true : false,
        	'autoplaytimeout' => !empty($settings['autoplaytimeout']) ? $settings['autoplaytimeout'] : '5000',
        );

        $jasondecode = wp_json_encode($slider_extraSetting);


        $this->add_render_attribute('slider_active', 'class', array('hero-slider-2','owl-carousel', 'owl-theme'));
        $this->add_render_attribute('slider_active', 'data-settings', $jasondecode);



       ?>
            <section class="hero-wrapper hero-2">
				<div <?php echo $this->get_render_attribute_string('slider_active'); ?>>
                    <?php foreach($contents as $content):
                             $target =   $content['h2_btn_one_url']['is_external'] ? ' target="_blank" ' : '';
                             $nofollow = $content['h2_btn_one_url']['nofollow'] ? ' rel="nofollow" ' : '';
                             $target_two =   $content['h2_btn_two_url']['is_external'] ? ' target="_blank" ' : '';
                             $nofollow_two = $content['h2_btn_two_url']['nofollow'] ? ' rel="nofollow" ' : '';                       
                        ?>
                            <div class="single-slide bg-cover" style="background-image: url(<?php echo esc_url($content['h_bg_image']['url']);?>)">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 pe-lg-5 col-xxl-7 col-lg-9">
                                            <div class="hero-contents pe-lg-3">
                                                <?php if($content['h_title']): ?>
                                                    <h1 class="wow fadeInLeft ">
                                                        <?php echo esc_html($content['h_title']); ?>
                                                    </h1>
                                                <?php endif; ?>
                                                
                                                <?php if($content['h_discription']): ?>
                                                    <p class="pe-lg-5 " >
                                                        <?php echo busico_get_meta($content['h_discription']); ?>
                                                    </p>
                                                <?php endif; ?>
                                                
                                                <?php if($content['h2_btn_one_text']): ?>
                                                    <a <?php printf('href="%s" %s %s', $content['h2_btn_one_url']['url'], $target, $nofollow); ?> class="theme-btn btn-one me-sm-4" >
                                                        <?php echo esc_html($content['h2_btn_one_text']); ?>
                                                    </a>
                                                <?php endif; ?>
                                                
                                                <?php if($content['h2_btn_two_text']): ?>
                                                    <a <?php printf('href="%s" %s %s', $content['h2_btn_one_url']['url'], $target, $nofollow); ?> class="theme-btn btn-two">
                                                        <?php echo esc_html($content['h2_btn_two_text']); ?>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                     <?php endforeach; ?>
				</div>
		    </section>
    <?php
    }
}
$widgets_manager->register_widget_type(new \Busico_Hero_Two());