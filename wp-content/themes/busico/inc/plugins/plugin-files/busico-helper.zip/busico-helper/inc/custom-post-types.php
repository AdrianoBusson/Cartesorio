<?php
// File Security Check
if (!defined('ABSPATH')) {
	exit;
}
class BusicoCustomPosts
{
	function __construct()
	{
		add_action( 'admin_menu', array($this, 'busico_header_footer_menu') );
		// Header
		add_action('init', array($this, 'busico_header'));
		add_action('init', array($this, 'busico_footer'));

		// team
        if (busico_check_cpt('team')) {
            add_action('init', array($this, 'busico_team'));
        }

		// services
        if (busico_check_cpt('service')) {
            add_action('init', array($this, 'busico_service'));
            add_action('init', array($this, 'busico_service_category'));
            add_action('init', array($this, 'busico_service_tags'));
        }

		// Portfolios
        if (busico_check_cpt('portfolio')) {
            add_action('init', array($this, 'busico_portfolio'));
            add_action('init', array($this, 'busico_portfolio_category'));
            add_action('init', array($this, 'busico_portfolio_tags'));
        }

		// Testimonial
        if (busico_check_cpt('testimonial')) {
            add_action('init', array($this, 'busico_testimonial'));
            add_action('init', array($this, 'busico_testimonial_category'));
        }

		// Case Study
        if (busico_check_cpt('case-study')) {
            add_action('init', array($this, 'busico_case_study'));
            add_action('init', array($this, 'busico_case_study_category'));
            add_action('init', array($this, 'busico_case_study_tags'));
        }

	}

	public function busico_header_footer_menu() {
		add_menu_page(
			'Header & Footer',
			'Header & Footer',
			'read',
			'header-footer',
			'',
			'dashicons-archive',
			40
		);
	 }
	 /**
	 *
	 * Busico Header Footer Post Type
	 *
	 */
	public function busico_header()
	{
		$labels = array(
			'name'               => _x('Header', 'post type general name', 'busico-hp'),
			'singular_name'      => _x('Header', 'post type singular name', 'busico-hp'),
			'menu_name'          => _x('Header', 'admin menu', 'busico-hp'),
			'name_admin_bar'     => _x('Header', 'add new on admin bar', 'busico-hp'),
			'add_new'            => __('Add New Header', 'busico-hp'),
			'add_new_item'       => __('Add New Header', 'busico-hp'),
			'new_item'           => __('New Header', 'busico-hp'),
			'edit_item'          => __('Edit Header', 'busico-hp'),
			'view_item'          => __('View Header', 'busico-hp'),
			'all_items'          => __('All Headers', 'busico-hp'),
			'search_items'       => __('Search Headers', 'busico-hp'),
			'parent_item_colon'  => __('Parent :', 'busico-hp'),
			'not_found'          => __('No Headers found.', 'busico-hp'),
			'not_found_in_trash' => __('No Headers found in Trash.', 'busico-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'busico-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'show_in_menu' 		 => 'header-footer',
			'rewrite'            => array('slug' => 'header'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title','elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('busico_header', $args);
	}

	public function busico_footer()
	{
		$labels = array(
			'name'               => _x('Footer', 'post type general name', 'busico-hp'),
			'singular_name'      => _x('Footer', 'post type singular name', 'busico-hp'),
			'menu_name'          => _x('Footer', 'admin menu', 'busico-hp'),
			'name_admin_bar'     => _x('Footer', 'add new on admin bar', 'busico-hp'),
			'add_new'            => __('Add New Footer', 'busico-hp'),
			'add_new_item'       => __('Add New Footer', 'busico-hp'),
			'new_item'           => __('New Footer', 'busico-hp'),
			'edit_item'          => __('Edit Footer', 'busico-hp'),
			'view_item'          => __('View Footer', 'busico-hp'),
			'all_items'          => __('All Footers', 'busico-hp'),
			'search_items'       => __('Search Footers', 'busico-hp'),
			'parent_item_colon'  => __('Parent :', 'busico-hp'),
			'not_found'          => __('No Footers found.', 'busico-hp'),
			'not_found_in_trash' => __('No Footers found in Trash.', 'busico-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'busico-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'footer'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'show_in_menu' 		 => 'header-footer',
			'supports'           => array('title','elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('busico_footer', $args);
	}

	/**
	 *
	 * busico Service Custom Post Type
	 *
	 */
	public function busico_service()
	{
		$labels = array(
			'name'               => _x('Service', 'post type general name', 'busico-hp'),
			'singular_name'      => _x('Service', 'post type singular name', 'busico-hp'),
			'menu_name'          => _x('Service', 'admin menu', 'busico-hp'),
			'name_admin_bar'     => _x('Service', 'add new on admin bar', 'busico-hp'),
			'add_new'            => __('Add New Service', 'busico-hp'),
			'add_new_item'       => __('Add New Service', 'busico-hp'),
			'new_item'           => __('New Service', 'busico-hp'),
			'edit_item'          => __('Edit Service', 'busico-hp'),
			'view_item'          => __('View Service', 'busico-hp'),
			'all_items'          => __('All Services', 'busico-hp'),
			'search_items'       => __('Search Services', 'busico-hp'),
			'parent_item_colon'  => __('Parent :', 'busico-hp'),
			'not_found'          => __('No Services found.', 'busico-hp'),
			'not_found_in_trash' => __('No Services found in Trash.', 'busico-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'busico-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-megaphone',
			'rewrite'            => array('slug' => 'service', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('elementor', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('service', $args);
	}
	public function busico_service_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'busico-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'busico-hp'),
			'search_items'      => __('Search Categories', 'busico-hp'),
			'all_items'         => __('All Categories', 'busico-hp'),
			'parent_item'       => __('Parent Category', 'busico-hp'),
			'parent_item_colon' => __('Parent Category:', 'busico-hp'),
			'edit_item'         => __('Edit Category', 'busico-hp'),
			'update_item'       => __('Update Category', 'busico-hp'),
			'add_new_item'      => __('Add New Category', 'busico-hp'),
			'new_item_name'     => __('New Category Name', 'busico-hp'),
			'menu_name'         => __('Category', 'busico-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'service-category'),
		);
		register_taxonomy('service-category', array('service'), $args);
	}
	public function busico_service_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'busico-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'busico-hp'),
			'search_items'      => __('Search Tags', 'busico-hp'),
			'all_items'         => __('All Tags', 'busico-hp'),
			'parent_item'       => __('Parent Tag', 'busico-hp'),
			'parent_item_colon' => __('Parent Tag:', 'busico-hp'),
			'edit_item'         => __('Edit Tag', 'busico-hp'),
			'update_item'       => __('Update Tag', 'busico-hp'),
			'add_new_item'      => __('Add New Tag', 'busico-hp'),
			'new_item_name'     => __('New Tag Name', 'busico-hp'),
			'menu_name'         => __('Tag', 'busico-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'pf-tag'),
		);
		register_taxonomy('service-tag', array('service'), $args);
	}
	/**
	 *
	 * Busico Team Post Type
	 *
	 */
	public function busico_team()
	{
		$labels = array(
			'name'               => _x('Team Member', 'post type general name', 'busico-hp'),
			'singular_name'      => _x('Team Member', 'post type singular name', 'busico-hp'),
			'menu_name'          => _x('Team Member', 'admin menu', 'busico-hp'),
			'name_admin_bar'     => _x('Team Member', 'add new on admin bar', 'busico-hp'),
			'add_new'            => __('Add New Member', 'busico-hp'),
			'add_new_item'       => __('Add New Member', 'busico-hp'),
			'new_item'           => __('New Member', 'busico-hp'),
			'edit_item'          => __('Edit Member', 'busico-hp'),
			'view_item'          => __('View Member', 'busico-hp'),
			'all_items'          => __('All Team Members', 'busico-hp'),
			'search_items'       => __('Search Team Members', 'busico-hp'),
			'parent_item_colon'  => __('Parent :', 'busico-hp'),
			'not_found'          => __('No Team Members found.', 'busico-hp'),
			'not_found_in_trash' => __('No Team Members found in Trash.', 'busico-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'busico-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'team', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'editor', 'thumbnail', 'elementor',  'page-attributes')
		);
		register_post_type('team', $args);
	}

	/**
	 *
	 * Busico Portfolio Post Type
	 *
	 */
	public function busico_portfolio()
	{
		$labels = array(
			'name'               => _x('Portfolio', 'post type general name', 'busico-hp'),
			'singular_name'      => _x('Portfolio', 'post type singular name', 'busico-hp'),
			'menu_name'          => _x('Portfolio', 'admin menu', 'busico-hp'),
			'name_admin_bar'     => _x('Portfolio', 'add new on admin bar', 'busico-hp'),
			'add_new'            => __('Add New Portfolio', 'busico-hp'),
			'add_new_item'       => __('Add New Portfolio', 'busico-hp'),
			'new_item'           => __('New Portfolio', 'busico-hp'),
			'edit_item'          => __('Edit Portfolio', 'busico-hp'),
			'view_item'          => __('View Portfolio', 'busico-hp'),
			'all_items'          => __('All Portfolios', 'busico-hp'),
			'search_items'       => __('Search Portfolios', 'busico-hp'),
			'parent_item_colon'  => __('Parent :', 'busico-hp'),
			'not_found'          => __('No Portfolios found.', 'busico-hp'),
			'not_found_in_trash' => __('No Portfolios found in Trash.', 'busico-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'busico-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'portfolio', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('portfolio', $args);
	}
	public function busico_portfolio_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'busico-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'busico-hp'),
			'search_items'      => __('Search Categories', 'busico-hp'),
			'all_items'         => __('All Categories', 'busico-hp'),
			'parent_item'       => __('Parent Category', 'busico-hp'),
			'parent_item_colon' => __('Parent Category:', 'busico-hp'),
			'edit_item'         => __('Edit Category', 'busico-hp'),
			'update_item'       => __('Update Category', 'busico-hp'),
			'add_new_item'      => __('Add New Category', 'busico-hp'),
			'new_item_name'     => __('New Category Name', 'busico-hp'),
			'menu_name'         => __('Category', 'busico-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-category'),
		);
		register_taxonomy('portfolio-category', array('portfolio'), $args);
	}
	public function busico_portfolio_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'busico-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'busico-hp'),
			'search_items'      => __('Search Tags', 'busico-hp'),
			'all_items'         => __('All Tags', 'busico-hp'),
			'parent_item'       => __('Parent Tag', 'busico-hp'),
			'parent_item_colon' => __('Parent Tag:', 'busico-hp'),
			'edit_item'         => __('Edit Tag', 'busico-hp'),
			'update_item'       => __('Update Tag', 'busico-hp'),
			'add_new_item'      => __('Add New Tag', 'busico-hp'),
			'new_item_name'     => __('New Tag Name', 'busico-hp'),
			'menu_name'         => __('Tag', 'busico-hp'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-tag'),
		);
		register_taxonomy('portfolio-tag', array('portfolio'), $args);
	}



	//Testimonial
	public function busico_testimonial()
	{
		$labels = array(
			'name'               => _x('Testimonial', 'post type general name', 'busico-hp'),
			'singular_name'      => _x('Testimonial', 'post type singular name', 'busico-hp'),
			'menu_name'          => _x('Testimonial', 'admin menu', 'busico-hp'),
			'name_admin_bar'     => _x('Testimonial', 'add new on admin bar', 'busico-hp'),
			'add_new'            => __('Add New Testimonial', 'busico-hp'),
			'add_new_item'       => __('Add New Testimonial', 'busico-hp'),
			'new_item'           => __('New Testimonial', 'busico-hp'),
			'edit_item'          => __('Edit Testimonial', 'busico-hp'),
			'view_item'          => __('View Testimonial', 'busico-hp'),
			'all_items'          => __('All Testimonial', 'busico-hp'),
			'search_items'       => __('Search Testimonial', 'busico-hp'),
			'parent_item_colon'  => __('Parent :', 'busico-hp'),
			'not_found'          => __('No Testimonial found.', 'busico-hp'),
			'not_found_in_trash' => __('No Testimonial found in Trash.', 'busico-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'busico-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-testimonial',
			'rewrite'            => array('slug' => 'busico_testimonial', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('busico_testimonial', $args);
	}
	public function busico_testimonial_category()
		{
			$labels = array(
				'name'              => _x('Categories', 'taxonomy general name', 'busico-hp'),
				'singular_name'     => _x('Category', 'taxonomy singular name', 'busico-hp'),
				'search_items'      => __('Search Categories', 'busico-hp'),
				'all_items'         => __('All Categories', 'busico-hp'),
				'parent_item'       => __('Parent Category', 'busico-hp'),
				'parent_item_colon' => __('Parent Category:', 'busico-hp'),
				'edit_item'         => __('Edit Category', 'busico-hp'),
				'update_item'       => __('Update Category', 'busico-hp'),
				'add_new_item'      => __('Add New Category', 'busico-hp'),
				'new_item_name'     => __('New Category Name', 'busico-hp'),
				'menu_name'         => __('Category', 'busico-hp'),
			);
			$args = array(
				'hierarchical'      => true,
				'labels'            => $labels,
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => array('slug' => 'portfolio-category'),
			);
			register_taxonomy('testimonial_category', array('busico_testimonial'), $args);
		}




	//Case Study
	public function busico_case_study()
	{
		$labels = array(
			'name'               => _x('Case Study', 'post type general name', 'busico-hp'),
			'singular_name'      => _x('Case Study', 'post type singular name', 'busico-hp'),
			'menu_name'          => _x('Case Study', 'admin menu', 'busico-hp'),
			'name_admin_bar'     => _x('Case Study', 'add new on admin bar', 'busico-hp'),
			'add_new'            => __('Add New Studies', 'busico-hp'),
			'add_new_item'       => __('Add New Studies', 'busico-hp'),
			'new_item'           => __('New Studies', 'busico-hp'),
			'edit_item'          => __('Edit Studies', 'busico-hp'),
			'view_item'          => __('View Studies', 'busico-hp'),
			'all_items'          => __('All Studies', 'busico-hp'),
			'search_items'       => __('Search Studies', 'busico-hp'),
			'parent_item_colon'  => __('Parent :', 'busico-hp'),
			'not_found'          => __('No Studies found.', 'busico-hp'),
			'not_found_in_trash' => __('No Studies found in Trash.', 'busico-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'busico-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-media-spreadsheet',
			'rewrite'            => array('slug' => 'case-studies', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'excerpt', 'thumbnail',  'page-attributes')
		);
		register_post_type('case-study', $args);
	}

	public function busico_case_study_category()
		{
			$labels = array(
				'name'              => _x('Categories', 'taxonomy general name', 'busico-hp'),
				'singular_name'     => _x('Category', 'taxonomy singular name', 'busico-hp'),
				'search_items'      => __('Search Categories', 'busico-hp'),
				'all_items'         => __('All Categories', 'busico-hp'),
				'parent_item'       => __('Parent Category', 'busico-hp'),
				'parent_item_colon' => __('Parent Category:', 'busico-hp'),
				'edit_item'         => __('Edit Category', 'busico-hp'),
				'update_item'       => __('Update Category', 'busico-hp'),
				'add_new_item'      => __('Add New Category', 'busico-hp'),
				'new_item_name'     => __('New Category Name', 'busico-hp'),
				'menu_name'         => __('Category', 'busico-hp'),
			);
			$args = array(
				'hierarchical'      => true,
				'labels'            => $labels,
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => array('slug' => 'studies_category'),
			);
			register_taxonomy('case-study-category', array('case-study'), $args);
		}

		public function busico_case_study_tags()
		{
			$labels = array(
				'name'              => _x('Tags', 'taxonomy general name', 'busico-hp'),
				'singular_name'     => _x('Tag', 'taxonomy singular name', 'busico-hp'),
				'search_items'      => __('Search Tags', 'busico-hp'),
				'all_items'         => __('All Tags', 'busico-hp'),
				'parent_item'       => __('Parent Tag', 'busico-hp'),
				'parent_item_colon' => __('Parent Tag:', 'busico-hp'),
				'edit_item'         => __('Edit Tag', 'busico-hp'),
				'update_item'       => __('Update Tag', 'busico-hp'),
				'add_new_item'      => __('Add New Tag', 'busico-hp'),
				'new_item_name'     => __('New Tag Name', 'busico-hp'),
				'menu_name'         => __('Tag', 'busico-hp'),
			);
			$args = array(
				'hierarchical'      => false,
				'labels'            => $labels,
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => array('slug' => 'studies-tag'),
			);
			register_taxonomy('studies-tag', array('case-study'), $args);
		}


}
$busicoCcases_stydyInstance = new BusicoCustomPosts;
