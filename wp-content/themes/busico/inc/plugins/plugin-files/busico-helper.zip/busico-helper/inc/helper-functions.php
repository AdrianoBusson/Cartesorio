<?php
if (!defined('ABSPATH')) {
    exit;
}


/**
 * Meta Output
 *
 * @since 1.0
 *
 * @return array
 */
if ( ! function_exists( 'busico_get_meta' ) ) {
    function busico_get_meta( $data ) {
        global $wp_embed;
        $content = $wp_embed->autoembed( $data );
        $content = $wp_embed->run_shortcode( $content );
        $content = do_shortcode( $content );
        $content = wpautop( $content );
        return $content;
    }
}

function busico_cpt_taxonomy_slug_and_name($taxonomy_name, $option_tag = false)
{
    $taxonomyies = get_terms($taxonomy_name);
    if(true == $option_tag){
        $cpt_terms = '';
        foreach ($taxonomyies as $category) {
            if( isset( $category->slug ) && isset( $category->name ) ){
               $cpt_terms .= '<option value="'. esc_attr( $category->slug) .'">'.  $category->name .'</option>';
            }
        }
        return $cpt_terms;
    }
    $cpt_terms = [];
    foreach ($taxonomyies as $category) {
        if( isset( $category->slug ) && isset( $category->name ) ){
            $cpt_terms[$category->slug] = $category->name;
        }
    }
    return $cpt_terms;
}




function busico_cpt_taxonomy_id_and_name($taxonomy_name)
{
    $taxonomyies = get_terms($taxonomy_name);
    $cpt_terms = [];
    foreach ($taxonomyies as $category) {
        $cpt_terms[$category->term_id] = $category->name;
    }
    return $cpt_terms;
}



function busico_cpt_author_slug_and_id($post_type)
{
    $the_query = new WP_Query(array(
        'posts_per_page' => -1,
        'post_type' => $post_type,
    ));
    $author_meta = [];
    while ($the_query->have_posts()) : $the_query->the_post();
        $author_meta[get_the_author_meta('ID')] = get_the_author_meta('display_name');
    endwhile;
    wp_reset_postdata();
    return array_unique($author_meta);
}

function busico_cpt_slug_and_id($post_type)
{
    $the_query = new WP_Query(array(
        'posts_per_page' => -1,
        'post_type' => $post_type,
    ));
    $cpt_posts = [];
    while ($the_query->have_posts()) : $the_query->the_post();
        $cpt_posts[get_the_ID()] = get_the_title();
    endwhile;
    wp_reset_postdata();
    return $cpt_posts;
}




function busico_loadmore_callback()
{
    // maybe it isn't the best way to declare global $post variable, but it is simple and works perfectly!
    $nonce = (isset($_POST['nonce'])) ? $_POST['nonce'] : '';
    if(check_ajax_referer( 'busico_loadmore_callback', 'folio_nonce' )){
        $settings = (isset($_POST['portfolio_settings'])) ? $_POST['portfolio_settings']['settings'] : [];
        $paged = (isset($_POST['paged'])) ? $_POST['paged'] : '';
        include(__DIR__ . '/../widgets/portfolio/queries/portfolio-query.php');
        include(__DIR__ . '/../widgets/portfolio/contents/portfolio-content.php');
        wp_reset_postdata();
        wp_die( ' ' );
    }else{
        echo "something wrong";
        wp_die( ' ' );
    }
}
add_action('wp_ajax_busico_loadmore_callback', 'busico_loadmore_callback'); // wp_ajax_{action}
add_action('wp_ajax_nopriv_busico_loadmore_callback', 'busico_loadmore_callback'); // wp_ajax_nopriv_{action}



function busico_start_modify_html() {
    ob_start();
 }
 function busico_end_modify_html() {
    $html = ob_get_clean();
    $html = str_replace( 'font-display:swap;', '', $html );
    echo $html;
 }
 add_action( 'wp_head', 'busico_start_modify_html' );
 add_action( 'wp_footer', 'busico_end_modify_html' );

//sakib

/**
 * Checking post type enablee or disabled
 */
function busico_check_cpt( $opt_id ){
    $busico = get_option( 'busico' );
    if( isset( $busico[$opt_id] ) ){
        if( true == $busico[$opt_id] ) {
            return true;
        }else{
            return false;
        }
    }else{
        return true;
    }
}


 /**
 * Meta shortcode content Output
 *
 * @since 1.0
 *
 * @return array
 */
if ( ! function_exists( 'busico_get_meta' ) ) {
    function busico_get_meta( $data ) {
        global $wp_embed;
        $content = $wp_embed->autoembed( $data );
        $content = $wp_embed->run_shortcode( $content );
        $content = do_shortcode( $content );
        $content = wpautop( $content );
        return $content;
    }
}

 /**
 * Check if contact form 7 is activated
 *
 * @return bool
 */
if ( ! function_exists( 'busico_is_cf7_activated' ) ) {
    function busico_is_cf7_activated() {
        return class_exists( 'WPCF7' );
    }
}


/**
 *
 * Implementing Feature in menu item
 *
 */
function busico_implement_menu_meta( $classes, $item ) {
    $class = get_field('hide_this_menu', $item) ? 'hide-label' : '';
    $class .= get_field('is_it_title', $item) ? 'megamenu-heading' : '';
    $class .= get_field('select_megamenu', $item) ? 'menu-item-has-children busico-megamenu-builder-parent busico-mega-menu' : '';
    $classes[] = $class;
    return $classes;
}
add_filter('nav_menu_css_class', 'busico_implement_menu_meta', 10, 2);


/**
 *  Menu items - Add "Custom sub-menu" in menu item render output
 *  if menu item has class "menu-item-target"
 */
function busico_megamenu_builder_integrations( $item_output, $item, $depth, $args ) {

    $selected_megamenu = get_field('select_megamenu', $item, true);
    if(!empty( $selected_megamenu ) ){
        if( ! array_key_exists('elementor-preview', $_GET)){
            $custom_sub_menu_html = "   <ul class='busico-megamenu-builder-content-wrap sub-menu'>
            <li>".busico_layout_content($selected_megamenu)."</li>
        </ul>";

            // Append after <a> element of the menu item targeted
            $item_output .= $custom_sub_menu_html;
        }
    }



    return $item_output;
}
add_filter( 'walker_nav_menu_start_el', 'busico_megamenu_builder_integrations', 10, 4 );


function busico_layout_content($post_id){

	return Elementor\Plugin::instance()->frontend->get_builder_content($post_id, true);
}

/**
 * Post orderby list
 */
function busico_get_post_orderby_options()
{
    $orderby = array(
        'ID' => 'Post ID',
        'author' => 'Post Author',
        'title' => 'Title',
        'date' => 'Date',
        'modified' => 'Last Modified Date',
        'parent' => 'Parent Id',
        'rand' => 'Random',
        'comment_count' => 'Comment Count',
        'menu_order' => 'Menu Order',
    );
    $orderby = apply_filters('busico_post_orderby', $orderby);
    return $orderby;
}


/**
 * Get Posts
 *
 * @since 1.0
 *
 * @return array
 */
if ( ! function_exists( 'busico_get_all_posts' ) ) {
    function busico_get_all_posts($posttype)
    {
        $args = array(
            'post_type' => $posttype,
            'post_status' => 'publish',
            'posts_per_page' => -1
        );

        $post_list = array();
        if( $data = get_posts($args)){
            foreach($data as $key){
                $post_list[$key->ID] = $key->post_title;
            }
        }
        return  $post_list;
    }
}


/**
 * Get Author list
 *
 * @since 1.0
 *
 * @return array
 */
if ( ! function_exists( 'busico_get_authors' ) )
{
    function busico_get_authors()
    {
        $user_query = new \WP_User_Query(
            [
                'who' => 'authors',
                'has_published_posts' => true,
                'fields' => [
                    'ID',
                    'display_name',
                ],
            ]
        );
        $authors = [];
        foreach ($user_query->get_results() as $result) {
            $authors[$result->ID] = $result->display_name;
        }
        return $authors;
    }
}


if ( ! function_exists( 'busico_post_excerpt' ) ) :
/**
 * Display post post excerpt or content
 * *
 * @since 1.0
 */
function busico_post_excerpt($post_id, $length = 20) {

    $post_object = get_post( $post_id );

    $excerpt = $post_object->post_excerpt;
    $content = $post_object->post_content;

    if ( !empty($excerpt)  && strlen(trim($excerpt)) != 0) {
        echo '<p>' . wp_trim_words( $excerpt, (int)$length, '' ) . '</p>';
    } else {
        echo '<p>' . wp_trim_words( $content, (int)$length, '' ) . '</p>';
    }

}
endif;



/**
 * Get taxonomy list
 *
 * @since 1.0
 *
 * @param string $taxonomy
 *
 * @return array
 */
if (!function_exists('busico_taxomony_list')) {
    function busico_taxomony_list($taxonomy)
    {

        $taxonomy_exist = taxonomy_exists($taxonomy);
        if (!$taxonomy_exist) {
            return;
        }
        $terms = get_terms(array(
            'taxonomy' => $taxonomy,
            'hide_empty' => 1
        ));

        $get_terms = array();

        if (!empty($terms)) {
            foreach ($terms as $term) :
                $get_terms[$term->slug] = $term->name;
            endforeach;
        }

        return $get_terms;
    }
}




if ( !function_exists( 'busico_posted_by' ) ):
    /**
     * Prints HTML with meta information for the current author.
     */
    function busico_posted_by($label = 'by' ) {


        $byline = sprintf(
            /* translators: %s: post author. */
            esc_html_x( '%s', 'post author', 'rr-addons' ),
            '<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"> ' . $label . esc_html( get_the_author() ) . '</a></span>'
        );
        return '<span class="byline"> '  . $byline . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

    }
endif;

if ( !function_exists( 'busico_posted_date' ) ):
    /**
     * Prints HTML with meta information for the current date.
     */
    function busico_posted_date( $icon ='' ) {
        $date_html = sprintf('<span class="post-date"> %s %s</span>', $icon, get_the_date(  ));
        return $date_html;
    }
endif;

if ( !function_exists( 'busico_posted_category' ) ):
    /**
     * Prints HTML with meta information for the current date.
     */
    function busico_posted_category( $icon ='' ) {

        $post_cat = get_the_terms(get_the_ID(), 'category');
        $post_cat = join(', ', wp_list_pluck($post_cat, 'name'));
        $post_category = sprintf('<span class="category-list"> %s %s</span>', $icon, $post_cat);

        return $post_category;

    }
endif;

if ( !function_exists( 'busico_comment_count_vtwo' ) ):
/**
 * Comment count
 */
    function busico_comment_count_vtwo() {
        if ( post_password_required() || !( comments_open() || get_comments_number() ) ) {
            return;
        }
        ?>
	    <span class="rr-addons-comment">
	        <ul class="list-inline">

	            <a href="<?php comments_link();?>">
	                <span><?php comments_number( '0', '1', '%' );?></span>
	            </a>
	        </ul>
	    </span>
	    <?php
    }
endif;

if ( !function_exists( 'busico_comment_count' ) ):
    /**
     * Comment count
     */
        function busico_comment_count($clabel = 'Comment', $icon = '') {
            if ( post_password_required() || !( comments_open() || get_comments_number() ) ) {
                return;
            }
            ob_start();
            ?>
            <span class="rr-addons-comment">
                <a href="<?php comments_link();?>">
                    <span><?php echo $icon ?> <?php comments_number( '0', '1', '%'  );?> <?php echo $clabel?></span>
                </a>
            </span>
            <?php
            return ob_get_clean();
        }
    endif;





















