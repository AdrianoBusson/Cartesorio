<?php 
use Elementor\Icons_Manager;
?>

<div class="busico-single-testimonial-item">
    <?php echo busico_get_meta( $content );?>
    <div class="busico-client-info">
        <h5><?php the_title(); ?></h5>
        <span><?php echo get_field('designation'); ?></span>
    </div>

    <?php if(has_post_thumbnail() ): ?>
        <div class="busico-client-img bg-cover bg-center" style="background-image: url(<?php the_post_thumbnail_url('full'); ?>)">
        </div>
    <?php endif; ?>
</div>