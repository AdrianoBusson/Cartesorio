<?php 
use Elementor\Icons_Manager;
?>

<div class="busico-single-testimonial-item <?php echo esc_attr($testimonial_version); ?>">

    
    <?php
        if (!empty($settings['quotes_icon'])) {
            ?>
                <div class="busico-testimonial__quotes-icon">
                    <?php Icons_Manager::render_icon($settings['quotes_icon'], ['aria-hidden' => 'true']); ?>
                </div>
            <?php
        }
    ?>

    <?php echo busico_get_meta( $content );?>

    <div class="busico-client-info">
        <h5><?php the_title(); ?></h5>
        <span><?php echo get_field('designation'); ?></span>
    </div>

</div>