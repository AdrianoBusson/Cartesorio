<div <?php echo $this->get_render_attribute_string('team_gride_classes'); ?>>
    <div class="single-item">
        <div class="team-wrapper">
            <?php if(has_post_thumbnail() ): ?>
                <a href="<?php the_permalink(); ?>" class="team-image">
                    <?php the_post_thumbnail('full');?>
                </a>
            <?php endif; ?>

        <div class="team-content-bottom">
            <a href="<?php the_permalink(); ?>" class="plus-btn">
                <i class="fa fa-plus"></i>
            </a>

            <div class="user-identity">
                <?php if (function_exists('the_field')): ?>
                    <span><a href="<?php the_permalink() ?>"><?php the_field('position')?></a></span>
                <?php endif;?>
                <h6><a href="<?php the_permalink() ?>"><?php the_title();?></a></h6>
            </div>

            <?php if (function_exists('the_field')  && 'yes' == $settings['show_socail_links'] ):
                $social_links = get_field('social_links'); ?>
                <div class="social-icons">
                    <ul class="list-unstyled">
                        <?php foreach( $social_links as  $social_link):  ?>
                        <li>
                            <a href="<?php echo esc_url($social_link['url']); ?>">
                            <?php echo $social_link['icon'] ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif;?>
        </div>
    </div>
</div>